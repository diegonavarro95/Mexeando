// src/main.tsx
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { initAuth } from './services/initAuth'

async function bootstrap() {
  await initAuth()
  createRoot(document.getElementById('root')!).render(<App />)
}

bootstrap()
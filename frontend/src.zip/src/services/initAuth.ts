/**
 * src/services/initAuth.ts
 *
 * Función de arranque de la app (spec §02, §06 "Flujo de datos").
 *
 * Flujo:
 *   1. Lee refreshToken de localStorage
 *   2. Si existe → POST /api/v1/auth/refresh
 *   3. Guarda accessToken + userData en authStore
 *   4. Si falla → clearAuth() y deja que el router redirija a /login
 *
 * Llamar UNA VEZ desde main.tsx antes de montar la app:
 *   await initAuth();
 *   ReactDOM.createRoot(...).render(<App />);
 */

import axios from 'axios';
import { useAuthStore } from '../store/authStore';
import { usePassportStore } from '../store/passportStore';

const BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000';

export async function initAuth(): Promise<void> {
  const { setAuth, setAuthReady, clearAuth } = useAuthStore.getState();

  const refreshToken = localStorage.getItem('refreshToken');

  if (!refreshToken) {
    // Sin token guardado → sesión nueva / anónima
    setAuthReady(true);
    return;
  }

  try {
    const { data } = await axios.post<{
      data: {
        accessToken: string;
        refreshToken: string;
        userId: string;
        role: string;
        displayName?: string;
        preferredLang?: string;
        pointBalance?: number;
      };
    }>(`${BASE_URL}/api/v1/auth/refresh`, { refreshToken });

    const {
      accessToken,
      refreshToken: newRefresh,
      userId,
      role,
      displayName,
      preferredLang,
      pointBalance,
    } = data.data;

    // Persiste el refresh token rotado
    localStorage.setItem('refreshToken', newRefresh);

    // Hidrata el store principal
    setAuth(accessToken, userId, role, displayName, preferredLang);

    // Sincroniza el saldo con el passportStore
    if (typeof pointBalance === 'number') {
      useAuthStore.getState().setPointBalance(pointBalance);
      usePassportStore.getState().setPointBalance(pointBalance);
    }
  } catch {
    // Refresh token expirado o inválido → logout silencioso
    // No redirigimos aquí para que el router decida (rutas protegidas vs. públicas)
    localStorage.removeItem('refreshToken');
    clearAuth();
  }
}
/**
 * src/pages/auth/LoginPage.tsx
 * P-02 — Inicio de sesión
 * Ruta: /login
 *
 * Spec §01 P-02:
 *  - Botón "Continuar con Google" (Supabase OAuth)
 *  - Separador "o con correo"
 *  - Campos email + password
 *  - Enlace "Olvidé mi contraseña"
 *  - Botón ENTRAR → POST /api/v1/auth/login
 *  - Redirige según role: tourist→/explore, owner→/owner/dashboard, admin→/admin
 *  - Enlace "Explorar sin cuenta" → /explore
 *  - Toast "Tu sesión expiró" si viene ?expired=1 (spec §07)
 */

import { useState, useEffect } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { api } from '../../services/api';
import { useAuthStore, type UserRole } from '../../store/authStore';
import { supabase } from '../../lib/l-supabase';

// ─── Helpers ─────────────────────────────────────────────────────────────────

const ROLE_REDIRECT: Record<UserRole, string> = {
  tourist: '/explore',
  owner:   '/owner/dashboard',
  admin:   '/admin',
};

// ─── Componente ───────────────────────────────────────────────────────────────

export default function LoginPage() {
  const navigate      = useNavigate();
  const [params]      = useSearchParams();
  const setAuth       = useAuthStore((s) => s.setAuth);

  const [email, setEmail]         = useState('');
  const [password, setPassword]   = useState('');
  const [showPass, setShowPass]   = useState(false);
  const [errorMsg, setErrorMsg]   = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [expired, setExpired]     = useState(false);

  // Muestra toast si viene de sesión expirada (spec §07)
  useEffect(() => {
    if (params.get('expired') === '1') {
      setExpired(true);
      const t = setTimeout(() => setExpired(false), 4000);
      return () => clearTimeout(t);
    }
  }, [params]);

  // ── Handlers ────────────────────────────────────────────────────────────────

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsLoading(true);

    try {
      const { data } = await api.post<{
        data: {
          accessToken: string;
          refreshToken: string;
          userId: string;
          role: string;
          displayName?: string;
          preferredLang?: string;
          pointBalance?: number;
        };
      }>('/api/v1/auth/login', { email, password });

      const { accessToken, refreshToken, userId, role, displayName, preferredLang, pointBalance } =
        data.data;

      localStorage.setItem('refreshToken', refreshToken);
      setAuth(accessToken, userId, role, displayName, preferredLang);

      if (typeof pointBalance === 'number') {
        useAuthStore.getState().setPointBalance(pointBalance);
      }

      navigate(ROLE_REDIRECT[role as UserRole] ?? '/explore', { replace: true });
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error ?? 'Credenciales inválidas. Intenta de nuevo.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogle = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/explore` },
    });
  };

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-bgDark flex items-center justify-center p-4">

      {/* Toast — sesión expirada */}
      {expired && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50
                        bg-rojo text-crema text-sm font-semibold px-5 py-3
                        rounded-full shadow-lg animate-bounce">
          Tu sesión expiró. Vuelve a iniciar sesión.
        </div>
      )}

      <div className="w-full max-w-sm flex flex-col items-center gap-6">

        {/* ── Logo ── */}
        <div className="flex flex-col items-center gap-1">
          <div className="flex gap-0.5 mb-1">
            <span className="w-5 h-1 rounded-full bg-[#006847]" />
            <span className="w-5 h-1 rounded-full bg-white" />
            <span className="w-5 h-1 rounded-full bg-rojo" />
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rojo shadow-[0_0_8px_#C1121F]" />
            <span className="text-crema font-bold text-xl tracking-widest uppercase">OLA MX</span>
          </div>
          <p className="text-crema text-2xl font-bold mt-2">Iniciar sesión</p>
          <p className="text-crema/50 text-sm">Bienvenido de vuelta</p>
        </div>

        {/* ── Google ── */}
        <button
          onClick={handleGoogle}
          className="w-full flex items-center justify-center gap-3
                     border border-crema/20 text-crema bg-crema/5
                     rounded-full py-3 text-sm font-semibold
                     hover:bg-crema/10 active:scale-95 transition-all"
        >
          <GoogleIcon />
          Continuar con Google
        </button>

        {/* ── Separador ── */}
        <div className="flex items-center gap-3 w-full">
          <span className="flex-1 h-px bg-crema/15" />
          <span className="text-crema/40 text-xs">o con correo</span>
          <span className="flex-1 h-px bg-crema/15" />
        </div>

        {/* ── Formulario ── */}
        <form onSubmit={handleLogin} className="w-full flex flex-col gap-4">

          {/* Email */}
          <div className="flex flex-col gap-1">
            <label className="text-crema/50 text-xs uppercase tracking-widest">
              Correo electrónico
            </label>
            <input
              type="email"
              placeholder="turista@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full bg-crema/5 border border-crema/20 text-crema
                         placeholder:text-crema/30 rounded-xl px-4 py-3 text-sm
                         focus:outline-none focus:border-amarillo/70 transition-colors"
            />
          </div>

          {/* Password */}
          <div className="flex flex-col gap-1">
            <label className="text-crema/50 text-xs uppercase tracking-widest">
              Contraseña
            </label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full bg-crema/5 border border-crema/20 text-crema
                           placeholder:text-crema/30 rounded-xl px-4 py-3 pr-11 text-sm
                           focus:outline-none focus:border-amarillo/70 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-crema/40 hover:text-crema/70"
              >
                {showPass ? <EyeOffIcon /> : <EyeIcon />}
              </button>
            </div>
            <div className="flex justify-end mt-0.5">
              <Link
                to="/forgot-password"
                className="text-amarillo text-xs hover:underline"
              >
                ¿Olvidaste tu contraseña?
              </Link>
            </div>
          </div>

          {/* Error */}
          {errorMsg && (
            <p className="text-rojo text-xs font-semibold bg-rojo/10 border border-rojo/30
                          rounded-xl px-4 py-2">
              {errorMsg}
            </p>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-rojo text-crema font-bold py-3.5 rounded-full
                       uppercase tracking-widest text-sm
                       shadow-[0_4px_20px_rgba(193,18,31,0.4)]
                       hover:bg-rojo/90 active:scale-95 disabled:opacity-50
                       transition-all duration-150"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <SpinnerIcon /> Entrando...
              </span>
            ) : (
              'Entrar'
            )}
          </button>
        </form>

        {/* ── Links ── */}
        <p className="text-crema/50 text-sm">
          ¿No tienes cuenta?{' '}
          <Link to="/register" className="text-rojo font-semibold hover:underline">
            Regístrate
          </Link>
        </p>
        <Link to="/explore" className="text-crema/40 text-xs hover:text-crema/70 transition-colors">
          Explorar sin cuenta →
        </Link>
      </div>
    </div>
  );
}

// ─── Micro-íconos SVG inline ──────────────────────────────────────────────────

function GoogleIcon() {
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
    </svg>
  );
}

function SpinnerIcon() {
  return (
    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
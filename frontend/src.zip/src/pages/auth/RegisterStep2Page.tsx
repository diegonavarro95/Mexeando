/**
 * src/pages/auth/RegisterStep2Page.tsx
 * P-04 — Registro Paso 2: tipo de cuenta
 * Ruta: /register/type
 *
 * Spec §01 P-04:
 *  - Barra de progreso (paso 2 activo)
 *  - Dos tarjetas: Turista (rol "tourist") y Dueño (rol "owner")
 *  - Selector de idioma preferido (preferred_lang enum: es,en,fr,pt,de,zh)
 *  - Checkbox de términos y condiciones
 *  - Aviso si es dueño
 *  - SIGUIENTE → llama POST /api/v1/auth/register (spec: el registro llama al endpoint UNA VEZ al final)
 *  - Redirige según role: tourist→/explore, owner→/owner/onboarding
 */

import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../../services/api';
import { useAuthStore, type UserRole } from '../../store/authStore';
import ProgressBar from '../../components/ui/RegisterProgressBar';

// ─── Tipos ────────────────────────────────────────────────────────────────────

type Role = 'tourist' | 'owner';

type LangOpt = { code: string; label: string; flag: string };

const LANGUAGES: LangOpt[] = [
  { code: 'es', label: 'MX Español',   flag: '🇲🇽' },
  { code: 'en', label: 'US English',   flag: '🇺🇸' },
  { code: 'fr', label: 'FR Français',  flag: '🇫🇷' },
  { code: 'pt', label: 'BR Português', flag: '🇧🇷' },
  { code: 'de', label: 'DE Deutsch',   flag: '🇩🇪' },
  { code: 'zh', label: 'CN 中文',       flag: '🇨🇳' },
];

const ROLE_REDIRECT: Record<UserRole, string> = {
  tourist: '/explore',
  owner:   '/owner/onboarding',
  admin:   '/admin',
};

// ─── Componente ───────────────────────────────────────────────────────────────

export default function RegisterStep2Page() {
  const navigate = useNavigate();
  const setAuth  = useAuthStore((s) => s.setAuth);

  const [role, setRole]           = useState<Role>('tourist');
  const [lang, setLang]           = useState<string>(
    localStorage.getItem('preferredLang') ?? 'es'
  );
  const [accepted, setAccepted]   = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg]   = useState('');

  // ── Submit final (spec: el registro llama al endpoint UNA SOLA VEZ al final) ──

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accepted) {
      setErrorMsg('Debes aceptar los Términos y Condiciones para continuar.');
      return;
    }

    // Recupera datos del paso 1
    const raw = sessionStorage.getItem('registerStep1');
    if (!raw) {
      navigate('/register');
      return;
    }
    const { displayName, email, password } = JSON.parse(raw) as {
      displayName: string;
      email: string;
      password: string;
    };

    setIsLoading(true);
    setErrorMsg('');

    try {
      const { data } = await api.post<{
        data: {
          accessToken: string;
          refreshToken: string;
          userId: string;
          role: string;
          displayName?: string;
        };
      }>('/api/v1/auth/register', {
        email,
        password,
        displayName,   // → campo display_name en tabla profiles
        role,
        preferredLang: lang,
      });

      const {
        accessToken,
        refreshToken,
        userId,
        role: returnedRole,
        displayName: returnedName,
      } = data.data;

      // Persiste tokens
      localStorage.setItem('refreshToken', refreshToken);
      localStorage.setItem('preferredLang', lang);

      // Hidrata el store
      setAuth(accessToken, userId, returnedRole, returnedName ?? displayName, lang);

      // Limpia datos temporales
      sessionStorage.removeItem('registerStep1');

      navigate(ROLE_REDIRECT[returnedRole as UserRole] ?? '/explore', { replace: true });
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error ?? 'Error al crear la cuenta. Intenta de nuevo.');
    } finally {
      setIsLoading(false);
    }
  };

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-bgDark flex items-center justify-center p-4">
      <div className="w-full max-w-sm flex flex-col items-center gap-6">

        {/* ── Logo ── */}
        <LogoHeader />

        {/* ── Progreso ── */}
        <ProgressBar currentStep={2} totalSteps={3} />

        {/* ── Título ── */}
        <div className="text-center">
          <p className="text-crema text-2xl font-bold">Tipo de cuenta</p>
          <p className="text-crema/50 text-sm mt-1">Paso 2 de 3 — ¿Cómo usarás la app?</p>
        </div>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-5">

          {/* ── Tarjetas de rol ── */}
          <div className="grid grid-cols-2 gap-3">
            <RoleCard
              id="tourist"
              icon="🗺️"
              title="Turista"
              desc="Explorar y descubrir negocios"
              selected={role === 'tourist'}
              onSelect={() => setRole('tourist')}
            />
            <RoleCard
              id="owner"
              icon="🏪"
              title="Dueño"
              desc="Registrar mi negocio"
              selected={role === 'owner'}
              onSelect={() => setRole('owner')}
            />
          </div>

          {/* ── Aviso para dueños ── */}
          {role === 'owner' && (
            <div className="bg-naranja/10 border border-naranja/40 rounded-xl px-4 py-3">
              <p className="text-crema/80 text-xs">
                <span className="text-naranja font-bold">Dueño de negocio:</span>{' '}
                después de crear tu cuenta, un asistente IA te guiará para registrar
                tu negocio paso a paso.
              </p>
            </div>
          )}

          {/* ── Idioma preferido ── */}
          <div className="flex flex-col gap-2">
            <label className="text-crema/50 text-xs uppercase tracking-widest">
              Idioma preferido
            </label>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              className="w-full bg-crema/5 border border-crema/20 text-crema
                         rounded-xl px-4 py-3 text-sm
                         focus:outline-none focus:border-amarillo/70
                         transition-colors appearance-none cursor-pointer"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="bg-bgDark text-crema">
                  {l.flag} {l.label}
                </option>
              ))}
            </select>
          </div>

          {/* ── Términos ── */}
          <label className="flex items-start gap-3 cursor-pointer">
            <div className="relative mt-0.5 flex-shrink-0">
              <input
                type="checkbox"
                checked={accepted}
                onChange={(e) => {
                  setAccepted(e.target.checked);
                  if (e.target.checked) setErrorMsg('');
                }}
                className="sr-only"
              />
              <div
                className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all
                  ${accepted ? 'bg-verde border-verde' : 'bg-transparent border-crema/30'}`}
              >
                {accepted && (
                  <svg className="w-3 h-3 text-crema" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>
            </div>
            <p className="text-crema/60 text-xs leading-relaxed">
              Acepto los{' '}
              <Link to="/terms" className="text-amarillo hover:underline">
                Términos y Condiciones
              </Link>{' '}
              y el aviso de privacidad
            </p>
          </label>

          {/* ── Error ── */}
          {errorMsg && (
            <p className="text-rojo text-xs font-semibold bg-rojo/10 border border-rojo/30
                          rounded-xl px-4 py-2">
              {errorMsg}
            </p>
          )}

          {/* ── Submit ── */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-rojo text-crema font-bold py-3.5 rounded-full
                       uppercase tracking-widest text-sm
                       shadow-[0_4px_20px_rgba(193,18,31,0.4)]
                       hover:bg-rojo/90 active:scale-95 disabled:opacity-50
                       transition-all duration-150"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <SpinnerIcon /> Creando cuenta...
              </span>
            ) : (
              'Siguiente →'
            )}
          </button>
        </form>

        {/* Volver */}
        <button
          onClick={() => navigate('/register')}
          className="text-crema/40 text-xs hover:text-crema/70 transition-colors"
        >
          ← Volver al paso anterior
        </button>
      </div>
    </div>
  );
}

// ─── Sub-componentes ─────────────────────────────────────────────────────────

function LogoHeader() {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="flex gap-0.5 mb-1">
        <span className="w-5 h-1 rounded-full bg-[#006847]" />
        <span className="w-5 h-1 rounded-full bg-white" />
        <span className="w-5 h-1 rounded-full bg-rojo" />
      </div>
      <div className="flex items-center gap-2">
        <span className="w-2.5 h-2.5 rounded-full bg-rojo shadow-[0_0_8px_#C1121F]" />
        <span className="text-crema font-bold text-xl tracking-widest uppercase">OLA MX</span>
      </div>
    </div>
  );
}

function RoleCard({
  id,
  icon,
  title,
  desc,
  selected,
  onSelect,
}: {
  id: string;
  icon: string;
  title: string;
  desc: string;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`
        flex flex-col items-center gap-2 p-4 rounded-2xl border text-center
        transition-all duration-150 active:scale-95
        ${selected
          ? 'bg-rojo/15 border-rojo text-crema shadow-[0_0_16px_rgba(193,18,31,0.3)]'
          : 'bg-crema/5 border-crema/20 text-crema/60 hover:border-crema/40 hover:text-crema/80'}
      `}
    >
      <span className="text-2xl">{icon}</span>
      <span className={`text-sm font-bold ${selected ? 'text-crema' : 'text-crema/70'}`}>
        {title}
      </span>
      <span className="text-xs text-crema/50 leading-tight">{desc}</span>
    </button>
  );
}

function SpinnerIcon() {
  return (
    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
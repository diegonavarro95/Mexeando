/**
 * src/pages/auth/RegisterStep1Page.tsx
 * P-03 — Registro Paso 1: datos personales
 * Ruta: /register
 *
 * Spec §01 P-03:
 *  - Barra de progreso 3 pasos (paso 1 activo)
 *  - Botón "Registrarse con Google"
 *  - Campo displayName (2-80 chars → campo display_name en BD)
 *  - Campo email
 *  - Campo password (mín 8 chars) + barra de fortaleza débil/media/fuerte
 *  - SIGUIENTE → guarda en sessionStorage y navega a /register/type
 *  - El endpoint POST /api/v1/auth/register se llama en el PASO 3 (spec §01 P-03 nota)
 */

import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../../lib/l-supabase';
import ProgressBar from '../../components/ui/RegisterProgressBar';

// ─── Helpers ─────────────────────────────────────────────────────────────────

type Strength = 'weak' | 'medium' | 'strong';

function getStrength(pwd: string): Strength {
  if (pwd.length < 8) return 'weak';
  const has = (re: RegExp) => re.test(pwd);
  const score =
    (has(/[a-z]/) ? 1 : 0) +
    (has(/[A-Z]/) ? 1 : 0) +
    (has(/[0-9]/) ? 1 : 0) +
    (has(/[^a-zA-Z0-9]/) ? 1 : 0);
  if (score <= 2) return 'weak';
  if (score === 3) return 'medium';
  return 'strong';
}

const STRENGTH_LABEL: Record<Strength, string> = {
  weak:   'Débil',
  medium: 'Media',
  strong: 'Fuerte',
};

const STRENGTH_COLOR: Record<Strength, string> = {
  weak:   'bg-rojo',
  medium: 'bg-amarillo',
  strong: 'bg-verde',
};

const STRENGTH_WIDTH: Record<Strength, string> = {
  weak:   'w-1/3',
  medium: 'w-2/3',
  strong: 'w-full',
};

// ─── Componente ───────────────────────────────────────────────────────────────

export default function RegisterStep1Page() {
  const navigate = useNavigate();

  const [displayName, setDisplayName]   = useState('');
  const [email, setEmail]               = useState('');
  const [password, setPassword]         = useState('');
  const [showPass, setShowPass]         = useState(false);
  const [errors, setErrors]             = useState<Record<string, string>>({});

  const strength = password.length > 0 ? getStrength(password) : null;

  // ── Validación local ────────────────────────────────────────────────────────

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (displayName.trim().length < 2)
      e.displayName = 'El nombre debe tener al menos 2 caracteres.';
    if (displayName.trim().length > 80)
      e.displayName = 'Máximo 80 caracteres.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      e.email = 'Correo electrónico inválido.';
    if (password.length < 8)
      e.password = 'La contraseña debe tener al menos 8 caracteres.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  // ── Handlers ────────────────────────────────────────────────────────────────

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Guardamos los datos en sessionStorage para el paso final
    sessionStorage.setItem(
      'registerStep1',
      JSON.stringify({ displayName: displayName.trim(), email, password })
    );
    navigate('/register/type');
  };

  const handleGoogle = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/explore` },
    });
  };

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-bgDark flex items-center justify-center p-4">
      <div className="w-full max-w-sm flex flex-col items-center gap-6">

        {/* ── Logo ── */}
        <LogoHeader />

        {/* ── Progreso ── */}
        <ProgressBar currentStep={1} totalSteps={3} />

        {/* ── Título ── */}
        <div className="text-center">
          <p className="text-crema text-2xl font-bold">Crear cuenta</p>
          <p className="text-crema/50 text-sm mt-1">Paso 1 de 3 — Tus datos</p>
        </div>

        {/* ── Google ── */}
        <button
          onClick={handleGoogle}
          className="w-full flex items-center justify-center gap-3
                     border border-crema/20 text-crema bg-crema/5
                     rounded-full py-3 text-sm font-semibold
                     hover:bg-crema/10 active:scale-95 transition-all"
        >
          <GoogleIcon />
          Registrarse con Google
        </button>

        {/* ── Separador ── */}
        <div className="flex items-center gap-3 w-full">
          <span className="flex-1 h-px bg-crema/15" />
          <span className="text-crema/40 text-xs">o manualmente</span>
          <span className="flex-1 h-px bg-crema/15" />
        </div>

        {/* ── Formulario ── */}
        <form onSubmit={handleNext} className="w-full flex flex-col gap-4">

          {/* Nombre de usuario */}
          <Field label="Nombre de usuario">
            <input
              type="text"
              placeholder="JuanViajero26"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={80}
              required
              className={inputClass(!!errors.displayName)}
            />
            {errors.displayName && <FieldError msg={errors.displayName} />}
          </Field>

          {/* Email */}
          <Field label="Correo electrónico">
            <input
              type="email"
              placeholder="juan@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className={inputClass(!!errors.email)}
            />
            {errors.email && <FieldError msg={errors.email} />}
          </Field>

          {/* Password */}
          <Field label="Contraseña">
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className={`${inputClass(!!errors.password)} pr-11`}
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-crema/40 hover:text-crema/70"
              >
                {showPass ? <EyeOffIcon /> : <EyeIcon />}
              </button>
            </div>
            {/* Barra de fortaleza */}
            {strength && (
              <div className="mt-1.5 flex flex-col gap-1">
                <div className="h-1 w-full bg-crema/10 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300
                                ${STRENGTH_COLOR[strength]} ${STRENGTH_WIDTH[strength]}`}
                  />
                </div>
                <p className={`text-xs font-semibold
                  ${strength === 'weak' ? 'text-rojo' : strength === 'medium' ? 'text-amarillo' : 'text-verde'}`}>
                  {STRENGTH_LABEL[strength]}
                </p>
              </div>
            )}
            {errors.password && <FieldError msg={errors.password} />}
          </Field>

          <button
            type="submit"
            className="w-full bg-rojo text-crema font-bold py-3.5 rounded-full
                       uppercase tracking-widest text-sm mt-2
                       shadow-[0_4px_20px_rgba(193,18,31,0.4)]
                       hover:bg-rojo/90 active:scale-95 transition-all duration-150"
          >
            Siguiente →
          </button>
        </form>

        <p className="text-crema/50 text-sm">
          ¿Ya tienes cuenta?{' '}
          <Link to="/login" className="text-rojo font-semibold hover:underline">
            Inicia sesión
          </Link>
        </p>
      </div>
    </div>
  );
}

// ─── Sub-componentes ─────────────────────────────────────────────────────────

function LogoHeader() {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="flex gap-0.5 mb-1">
        <span className="w-5 h-1 rounded-full bg-[#006847]" />
        <span className="w-5 h-1 rounded-full bg-white" />
        <span className="w-5 h-1 rounded-full bg-rojo" />
      </div>
      <div className="flex items-center gap-2">
        <span className="w-2.5 h-2.5 rounded-full bg-rojo shadow-[0_0_8px_#C1121F]" />
        <span className="text-crema font-bold text-xl tracking-widest uppercase">OLA MX</span>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-crema/50 text-xs uppercase tracking-widest">{label}</label>
      {children}
    </div>
  );
}

function FieldError({ msg }: { msg: string }) {
  return <p className="text-rojo text-xs mt-0.5">{msg}</p>;
}

function inputClass(hasError: boolean) {
  return `w-full bg-crema/5 border text-crema placeholder:text-crema/30
          rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors
          ${hasError
            ? 'border-rojo/70 focus:border-rojo'
            : 'border-crema/20 focus:border-amarillo/70'}`;
}

function GoogleIcon() {
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
    </svg>
  );
}
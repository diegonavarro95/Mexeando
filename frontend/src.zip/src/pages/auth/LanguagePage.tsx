/**
 * src/pages/auth/LanguagePage.tsx
 * P-01 — Selección de idioma
 * Ruta: /
 *
 * Solo aparece la primera vez. Si ya existe "preferredLang" en
 * localStorage se salta directamente a /login (ver App.tsx).
 *
 * Spec §01 P-01:
 *  - 6 pills de idioma
 *  - Guarda en localStorage["preferredLang"]
 *  - i18next.changeLanguage()
 *  - Botón CONTINUAR → /login
 *  - Enlace "Explorar sin cuenta" → /explore
 */

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import i18n from 'i18next';

// ─── Tipos ────────────────────────────────────────────────────────────────────

type LangOption = {
  code: string;
  label: string;
  flag: string;
  region: string;
};

// ─── Datos ────────────────────────────────────────────────────────────────────

const LANGUAGES: LangOption[] = [
  { code: 'es', label: 'Español',   flag: '🇲🇽', region: 'MX' },
  { code: 'en', label: 'English',   flag: '🇺🇸', region: 'US' },
  { code: 'fr', label: 'Français',  flag: '🇫🇷', region: 'FR' },
  { code: 'pt', label: 'Português', flag: '🇧🇷', region: 'BR' },
  { code: 'de', label: 'Deutsch',   flag: '🇩🇪', region: 'DE' },
  { code: 'zh', label: '中文',       flag: '🇨🇳', region: 'CN' },
];

// ─── Componente ───────────────────────────────────────────────────────────────

export default function LanguagePage() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<string>('es');

  const handleContinue = () => {
    // Persiste en localStorage (spec §01 P-01)
    localStorage.setItem('preferredLang', selected);
    // Cambia el idioma en i18next
    i18n.changeLanguage(selected).catch(console.error);
    navigate('/login');
  };

  const handleExploreWithout = () => {
    localStorage.setItem('preferredLang', selected);
    i18n.changeLanguage(selected).catch(console.error);
    navigate('/explore');
  };

  return (
    <div className="min-h-screen bg-bgDark flex items-center justify-center p-4">
      {/* Tarjeta PWA — ancho máximo de móvil */}
      <div className="w-full max-w-sm flex flex-col items-center gap-6">

        {/* ── Logo ── */}
        <div className="flex flex-col items-center gap-1">
          {/* Tricolor mexicano */}
          <div className="flex gap-0.5 mb-1">
            <span className="w-5 h-1 rounded-full bg-[#006847]" />
            <span className="w-5 h-1 rounded-full bg-white" />
            <span className="w-5 h-1 rounded-full bg-rojo" />
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rojo shadow-[0_0_8px_#C1121F]" />
            <span className="text-crema font-bold text-xl tracking-widest uppercase">
              OLA MX
            </span>
          </div>
          <p className="text-crema text-3xl font-bold mt-2">Bienvenido</p>
          <p className="text-crema/60 text-sm">
            Choose your language / Elige tu idioma
          </p>
        </div>

        {/* ── Pills de idioma ── */}
        <div className="grid grid-cols-2 gap-3 w-full">
          {LANGUAGES.map((lang) => {
            const isActive = selected === lang.code;
            return (
              <button
                key={lang.code}
                onClick={() => setSelected(lang.code)}
                className={`
                  flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-semibold
                  transition-all duration-150 active:scale-95
                  ${isActive
                    ? 'bg-rojo border-rojo text-crema shadow-[0_0_12px_rgba(193,18,31,0.5)]'
                    : 'bg-transparent border-crema/30 text-crema/70 hover:border-crema/60 hover:text-crema'}
                `}
              >
                <span className="text-base">{lang.flag}</span>
                <span className="text-xs text-crema/50">{lang.region}</span>
                <span>{lang.label}</span>
              </button>
            );
          })}
        </div>

        {/* ── Tip ── */}
        <div className="w-full bg-amarillo/10 border border-amarillo/30 rounded-xl px-4 py-3">
          <p className="text-crema/80 text-xs text-left">
            <span className="text-amarillo font-bold">Tip:</span>{' '}
            Puedes cambiar el idioma en cualquier momento desde tu perfil.
          </p>
        </div>

        {/* ── CTA ── */}
        <button
          onClick={handleContinue}
          className="w-full bg-rojo text-crema font-bold py-3.5 rounded-full text-base
                     shadow-[0_4px_20px_rgba(193,18,31,0.4)] hover:bg-rojo/90
                     active:scale-95 transition-all duration-150 uppercase tracking-widest"
        >
          Continuar →
        </button>

        <button
          onClick={handleExploreWithout}
          className="text-crema/50 text-sm hover:text-crema/80 transition-colors"
        >
          Explorar sin cuenta
        </button>
      </div>
    </div>
  );
}
/**
 * src/pages/tourist/ExplorePage.tsx
 * T-1 — Explorar (pantalla principal del turista)
 * Ruta: /explore
 *
 * Spec §02 T-1:
 *  - Header con logo + nombre del usuario (o "Explorar" si anónimo)
 *  - Barra de búsqueda (parámetro q)
 *  - Chips de filtro por categoría (slugs: food,crafts,tourism,entertainment,wellness,retail)
 *  - Mapa Google Maps (placeholder — integración real en Fase siguiente)
 *  - Lista ordenada por indice_ola
 *  - GET /api/v1/businesses?lat=&lng=&radius=&category_id=&limit=
 *  - Comportamiento offline: banner amarillo + datos de IndexedDB
 *  - BottomNav
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate }    from 'react-router-dom';
import { useAuthStore }   from '../../store/authStore';
import { useMapStore }    from '../../store/MapStore';
import { api }            from '../../services/api';
import BusinessCard       from '../../components/map/BusinessCard';
import BottomNav          from '../../components/ui/BottomNav';
import type { BusinessMapResult } from '../../store/MapStore';

// ─── Categorías (spec §02 T-1) ────────────────────────────────────────────────

const CATEGORIES = [
  { id: null, label: 'Todo',        icon: '🌮' },
  { id: 1,    label: 'Comida',      icon: '🍽️' },
  { id: 2,    label: 'Artesanías',  icon: '🎨' },
  { id: 3,    label: 'Tours',       icon: '🗺️' },
  { id: 4,    label: 'Arte',        icon: '🎭' },
  { id: 5,    label: 'Bienestar',   icon: '🧘' },
  { id: 6,    label: 'Comercio',    icon: '🛍️' },
];

// ─── IndexedDB helper (offline cache) ────────────────────────────────────────

const IDB_KEY = 'garnacha_businesses_cache';

function saveToIDB(data: BusinessMapResult[]) {
  try { localStorage.setItem(IDB_KEY, JSON.stringify(data)); } catch {}
}
function loadFromIDB(): BusinessMapResult[] {
  try {
    const raw = localStorage.getItem(IDB_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

// ─── Componente ───────────────────────────────────────────────────────────────

export default function ExplorePage() {
  const navigate      = useNavigate();
  const displayName   = useAuthStore((s) => s.displayName);

  const {
    businesses, categoryId, radius, searchQuery,
    userLat, userLng, locationDenied, isLoading, isOffline,
    setBusinesses, setCategoryId, setSearchQuery,
    setUserLocation, setLocationDenied, setLoading, setError, setOffline,
  } = useMapStore();

  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [localSearch, setLocalSearch] = useState(searchQuery);

  // ── Geolocalización ──────────────────────────────────────────────────────────

  useEffect(() => {
    if (userLat !== null) return; // ya tenemos ubicación

    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        setUserLocation(coords.latitude, coords.longitude);
      },
      () => setLocationDenied(true),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }, []);

  // ── Fetch de negocios ─────────────────────────────────────────────────────────

  const fetchBusinesses = useCallback(async (q?: string) => {
    if (userLat === null || userLng === null) return;
    setLoading(true);

    try {
      const params: Record<string, string | number> = {
        lat:    userLat,
        lng:    userLng,
        radius: radius,
        limit:  30,
      };
      if (categoryId !== null) params.category_id = categoryId;
      if (q ?? searchQuery)    params.q = q ?? searchQuery;

      const { data } = await api.get<{ data: { businesses: BusinessMapResult[] } }>(
        '/api/v1/businesses',
        { params }
      );

      const list = data.data.businesses ?? [];
      setBusinesses(list);
      saveToIDB(list);
      setOffline(false);
    } catch {
      // Sin conexión → cargar caché
      const cached = loadFromIDB();
      if (cached.length) {
        setBusinesses(cached);
        setOffline(true);
      } else {
        setError('No se pudieron cargar los negocios.');
      }
    }
  }, [userLat, userLng, categoryId, radius, searchQuery]);

  // Refetch cuando cambian lat/lng o filtros
  useEffect(() => {
    if (userLat !== null) fetchBusinesses();
  }, [userLat, userLng, categoryId]);

  // Debounce búsqueda
  const handleSearchChange = (val: string) => {
    setLocalSearch(val);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      setSearchQuery(val);
      fetchBusinesses(val);
    }, 400);
  };

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-bgDark flex flex-col">

      {/* ── Header ── */}
      <header className="px-4 pt-4 pb-2 flex items-center justify-between">
        <div>
          {/* Tricolor */}
          <div className="flex gap-0.5 mb-0.5">
            <span className="w-4 h-0.5 rounded-full bg-[#006847]" />
            <span className="w-4 h-0.5 rounded-full bg-white" />
            <span className="w-4 h-0.5 rounded-full bg-rojo" />
          </div>
          <p className="text-crema text-xl font-bold">
            {displayName ? `Hola, ${displayName.split(' ')[0]}` : 'Explorar'}
          </p>
        </div>
        {/* Avatar */}
        <button
          onClick={() => navigate('/profile')}
          className="w-9 h-9 rounded-full bg-rojo flex items-center justify-center
                     text-crema font-bold text-sm shadow-[0_0_12px_rgba(193,18,31,0.4)]"
        >
          {displayName ? displayName[0].toUpperCase() : '?'}
        </button>
      </header>

      {/* ── Banner offline ── */}
      {isOffline && (
        <div className="mx-4 mb-2 bg-amarillo/20 border border-amarillo/50 rounded-xl
                        px-4 py-2 flex items-center gap-2">
          <span className="text-amarillo text-base">⚠️</span>
          <p className="text-amarillo text-xs font-semibold">
            Sin conexión — mostrando datos guardados
          </p>
        </div>
      )}

      {/* ── Sin GPS ── */}
      {locationDenied && (
        <div className="mx-4 mb-2 bg-rojo/10 border border-rojo/30 rounded-xl
                        px-4 py-2 flex items-center gap-2">
          <span className="text-rojo text-base">📍</span>
          <p className="text-crema/70 text-xs">
            Activa la ubicación para ver negocios cercanos.
          </p>
        </div>
      )}

      {/* ── Barra de búsqueda ── */}
      <div className="px-4 mb-3">
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-crema/40"
            fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Buscar tacos, tours..."
            value={localSearch}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="w-full bg-crema/5 border border-crema/15 text-crema
                       placeholder:text-crema/30 rounded-xl pl-9 pr-4 py-2.5 text-sm
                       focus:outline-none focus:border-amarillo/50 transition-colors"
          />
        </div>
      </div>

      {/* ── Chips de categoría ── */}
      <div className="px-4 mb-3 flex gap-2 overflow-x-auto pb-1
                      scrollbar-hide [&::-webkit-scrollbar]:hidden">
        {CATEGORIES.map((cat) => {
          const isActive = categoryId === cat.id;
          return (
            <button
              key={String(cat.id)}
              onClick={() => setCategoryId(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full
                          text-xs font-semibold flex-shrink-0 transition-all duration-150
                          active:scale-95
                          ${isActive
                            ? 'bg-rojo text-crema shadow-[0_0_10px_rgba(193,18,31,0.4)]'
                            : 'bg-crema/8 border border-crema/15 text-crema/60 hover:text-crema hover:border-crema/30'}`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* ── Mapa (placeholder Google Maps) ── */}
      <div className="mx-4 mb-3 rounded-2xl overflow-hidden border border-crema/10
                      bg-[#1a2e1a] relative" style={{ height: 180 }}>
        {/* Cuadrícula simulada de mapa */}
        <div className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,243,220,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,243,220,0.1) 1px, transparent 1px)',
            backgroundSize: '30px 30px',
          }}
        />
        {/* Pin central */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 bg-rojo rounded-full flex items-center justify-center
                            shadow-[0_0_16px_rgba(193,18,31,0.6)] text-crema text-base">
              📍
            </div>
            <div className="w-0.5 h-3 bg-rojo/60" />
          </div>
        </div>
        {/* Pins de negocios simulados */}
        {businesses.slice(0, 4).map((b, i) => (
          <button
            key={b.id}
            onClick={() => navigate(`/business/${b.id}`)}
            className="absolute text-xl hover:scale-110 transition-transform"
            style={{
              top:  `${20 + (i * 18) % 60}%`,
              left: `${15 + (i * 23) % 70}%`,
            }}
          >
            {b.category_icon}
          </button>
        ))}
        {/* Contador */}
        {businesses.length > 0 && (
          <div className="absolute bottom-2 right-2 bg-rojo text-crema
                          text-xs font-bold px-2.5 py-1 rounded-full
                          shadow-[0_0_10px_rgba(193,18,31,0.5)]">
            {businesses.length} cerca
          </div>
        )}
        {/* Label */}
        <p className="absolute top-2 left-3 text-crema/30 text-xs font-semibold uppercase tracking-widest">
          Mapa
        </p>
      </div>

      {/* ── Lista de negocios ── */}
      <div className="flex-1 px-4 pb-20 flex flex-col gap-2 overflow-y-auto">
        {isLoading ? (
          // Skeleton
          Array.from({ length: 4 }, (_, i) => (
            <div key={i} className="h-20 rounded-2xl bg-crema/5 animate-pulse" />
          ))
        ) : businesses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <span className="text-5xl">🔍</span>
            <p className="text-crema/50 text-sm text-center">
              No encontramos negocios cerca.{' '}
              {categoryId !== null && (
                <button
                  onClick={() => setCategoryId(null)}
                  className="text-amarillo underline"
                >
                  Ver todos
                </button>
              )}
            </p>
          </div>
        ) : (
          businesses.map((biz) => (
            <BusinessCard key={biz.id} business={biz} />
          ))
        )}
      </div>

      {/* ── Nav ── */}
      <BottomNav activeTab="explore" />
    </div>
  );
}
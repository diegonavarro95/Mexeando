import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Package, ArrowLeft, RefreshCw, Trophy } from 'lucide-react'
import { usePassportStore, type StampCollection } from '../../store/passportStore'
import { useAuthStore } from '../../store/authStore'
import { api } from '../../services/api'
import StampGrid, { type Stamp } from '../../components/StampGrid'
import PointsCounter from '../../components/PointsCounter'



interface OpenPackResponse {
  new_stamp_ids: number[]
  point_balance: number
  message: string
}

interface PointsResponse {
  point_balance: number
}

// Aplana todas las colecciones en un array plano que entiende StampGrid
function flattenStamps(album: StampCollection[]): Stamp[] {
  return album.flatMap((col) =>
    col.stamps.map((s) => ({
      ...s,
      rarity: 'common' as const, // el backend no envía rareza aún; se puede mapear después
    }))
  )
}

const PACK_COST = 200

export default function PassportPage() {
  const navigate  = useNavigate()
const { displayName } = useAuthStore()

  const {
    album,
    pointBalance,
    isLoading,
    isOpeningPack,
    newlyRevealedStampIds,
    setAlbum,
    setPointBalance,
    addStamps,
    setOpeningPack,
    clearNewlyRevealed,
    setLoading,
    setError,
  } = usePassportStore()

  const [showResult, setShowResult]       = useState(false)
  const [activeTab, setActiveTab]         = useState<'album' | 'progress'>('album')
  const [selectedStamp, setSelectedStamp] = useState<Stamp | null>(null)

  const canOpenPack = pointBalance >= PACK_COST

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    setLoading(true)
    try {
      const [albumRes, pointsRes] = await Promise.all([
        api.get<{ collections: StampCollection[] }>('/api/v1/passport/album'),
        api.get<PointsResponse>('/api/v1/passport/points'),
      ])
      setAlbum(albumRes.data.collections)
      setPointBalance(pointsRes.data.point_balance)
    } catch (err) {
      setError('No se pudo cargar el pasaporte.')
      console.error(err)
    }
  }

  async function handleOpenPack() {
    if (!canOpenPack || isOpeningPack) return
    setOpeningPack(true)
    try {
      const res = await api.post<OpenPackResponse>('/api/v1/passport/open-pack')
      addStamps(res.data.new_stamp_ids)
      setPointBalance(res.data.point_balance)
      setShowResult(true)
    } catch (err) {
      setError('No se pudo abrir el sobre.')
      console.error(err)
    } finally {
      setOpeningPack(false)
    }
  }

  function handleCloseResult() {
    setShowResult(false)
    clearNewlyRevealed()
  }

  const flatStamps  = flattenStamps(album)
  const newStamps   = flatStamps.filter((s) => newlyRevealedStampIds.includes(s.id))

  // Stats totales
  const totalObtained = album.reduce((acc, col) => acc + col.obtained_stamps, 0)
  const totalStamps   = album.reduce((acc, col) => acc + col.total_stamps, 0)
  const completionPct = totalStamps > 0 ? Math.round((totalObtained / totalStamps) * 100) : 0

  return (
    <div className="min-h-screen bg-[#110800] text-[#FFF3DC]">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#110800]/95 backdrop-blur border-b border-[#2a1800] px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 text-[#FFF3DC]/60 hover:text-[#FFF3DC] transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex flex-col items-center">
            <h1 className="text-base font-black text-[#FFF3DC] tracking-tight">
              Pasaporte del Mundial
            </h1>
            <p className="text-[10px] text-[#FFF3DC]/40">{displayName}</p>
          </div>
          <PointsCounter points={pointBalance} size="sm" />
        </div>
      </header>

      <main className="pb-24">
        {/* Pack Banner */}
        <div className="px-4 py-4">
          <div
            className={`relative overflow-hidden rounded-2xl p-4 border transition-all duration-500 ${
              canOpenPack
                ? 'bg-[#F4A300]/10 border-[#F4A300]/50 shadow-[0_0_20px_rgba(244,163,0,0.15)]'
                : 'bg-[#1a0d00] border-[#2a1800]'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#FFF3DC]/50 mb-0.5">Colección de estampas</p>
                <p className="text-lg font-black text-[#FFF3DC]">Sobre sorpresa</p>
                <p className="text-sm text-[#FFF3DC]/60 mt-1">
                  {canOpenPack ? (
                    <span className="text-[#F4A300] font-semibold">¡Tienes suficientes puntos!</span>
                  ) : (
                    <>Necesitas <strong className="text-[#FFF3DC]">{PACK_COST - pointBalance} pts</strong> más</>
                  )}
                </p>
                <PointsCounter
                  points={pointBalance}
                  threshold={PACK_COST}
                  showProgress
                  size="sm"
                  className="mt-2"
                />
              </div>

              <button
                onClick={handleOpenPack}
                disabled={!canOpenPack || isOpeningPack}
                className={`flex flex-col items-center gap-1 px-5 py-3 rounded-xl font-black text-sm transition-all duration-200 active:scale-95
                  ${canOpenPack
                    ? 'bg-[#F4A300] text-[#110800] shadow-[0_4px_15px_rgba(244,163,0,0.35)]'
                    : 'bg-[#2a1800] text-[#FFF3DC]/30 cursor-not-allowed'
                  }`}
              >
                {isOpeningPack
                  ? <RefreshCw size={22} className="animate-spin" />
                  : <Package size={22} />
                }
                <span>{isOpeningPack ? 'Abriendo…' : 'Abrir sobre'}</span>
                <span className="text-[10px] font-normal opacity-70">{PACK_COST} pts</span>
              </button>
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="px-4 grid grid-cols-3 gap-2 mb-4">
          {[
            { label: 'Obtenidas', value: totalObtained, emoji: '⭐' },
            { label: 'Total',     value: totalStamps,   emoji: '📦' },
            { label: 'Completado', value: `${completionPct}%`, emoji: '🏆' },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-[#1a0d00] border border-[#2a1800] rounded-xl p-3 flex flex-col items-center gap-1"
            >
              <span className="text-lg leading-none">{stat.emoji}</span>
              <span className="text-lg font-black text-[#FFF3DC]">{stat.value}</span>
              <span className="text-[10px] text-[#FFF3DC]/40">{stat.label}</span>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="px-4 flex gap-2 mb-4">
          {(['album', 'progress'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-sm font-bold transition-all duration-200 ${
                activeTab === tab
                  ? 'bg-[#C1121F] text-white'
                  : 'bg-[#1a0d00] text-[#FFF3DC]/50 border border-[#2a1800]'
              }`}
            >
              {tab === 'album' ? '📒 Álbum' : '📊 Progreso'}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <RefreshCw size={24} className="animate-spin text-[#C1121F]" />
          </div>
        ) : activeTab === 'album' ? (
          <div className="px-4">
            {album.length === 0 ? (
              <p className="text-center text-[#FFF3DC]/30 text-sm py-10">
                Aún no tienes estampas. ¡Haz un check-in!
              </p>
            ) : (
              album.map((col) => (
                <div key={col.collection_slug} className="mb-6">
                  <p className="text-xs font-bold text-[#FFF3DC]/50 uppercase tracking-widest mb-2 px-1">
                    {col.collection_name}
                    <span className="ml-2 text-[#FFF3DC]/30 normal-case font-normal">
                      {col.obtained_stamps}/{col.total_stamps}
                    </span>
                  </p>
                  <StampGrid
                    stamps={col.stamps.map((s) => ({ ...s, rarity: 'common' as const }))}
                    cols={4}
                    showLocked
                    onStampClick={setSelectedStamp}
                  />
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="px-4 space-y-3">
            {album.map((col) => (
              <div key={col.collection_slug} className="bg-[#1a0d00] border border-[#2a1800] rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold text-[#FFF3DC]">{col.collection_name}</span>
                  <span className="text-xs text-[#FFF3DC]/50">
                    {col.obtained_stamps}/{col.total_stamps}
                  </span>
                </div>
                <div className="w-full h-2 bg-[#2a1800] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#C1121F] rounded-full transition-all duration-700"
                    style={{ width: `${col.completion_pct}%` }}
                  />
                </div>
                {col.is_complete && (
                  <p className="text-[10px] text-[#F4A300] font-bold mt-1">¡Colección completa! 🎉</p>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Stamp detail modal */}
      <AnimatePresence>
        {selectedStamp && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 flex items-end justify-center p-4"
            onClick={() => setSelectedStamp(null)}
          >
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 80, opacity: 0 }}
              className="bg-[#1a0d00] border border-[#3d2200] rounded-2xl p-6 w-full max-w-sm text-center"
             onClick={(e: React.MouseEvent) => e.stopPropagation()}
            >
              {selectedStamp.icon.startsWith('http') ? (
                <img src={selectedStamp.icon} alt={selectedStamp.name} className="w-16 h-16 mx-auto mb-3 object-contain" />
              ) : (
                <span className="text-6xl mb-3 block">{selectedStamp.icon}</span>
              )}
              <h3 className="text-xl font-black text-[#FFF3DC] mb-1">{selectedStamp.name}</h3>
              <span className="text-xs font-bold capitalize text-[#F4A300] px-3 py-1 bg-[#F4A300]/10 rounded-full">
                {selectedStamp.collection_slug}
              </span>
              {selectedStamp.description && (
                <p className="text-sm text-[#FFF3DC]/60 mt-3 leading-relaxed">
                  {selectedStamp.description}
                </p>
              )}
              {selectedStamp.exclusive_city && (
                <p className="text-xs text-[#C1121F] mt-2">
                  Exclusiva de {selectedStamp.exclusive_city}
                </p>
              )}
              {selectedStamp.obtained_at && (
                <p className="text-xs text-[#FFF3DC]/30 mt-2">
                  Obtenida el{' '}
                  {new Date(selectedStamp.obtained_at).toLocaleDateString('es-MX', {
                    day: 'numeric', month: 'long', year: 'numeric',
                  })}
                </p>
              )}
              <button
                onClick={() => setSelectedStamp(null)}
                className="mt-4 w-full py-3 bg-[#2a1800] rounded-xl text-[#FFF3DC]/60 font-semibold text-sm"
              >
                Cerrar
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Pack result modal */}
      <AnimatePresence>
        {showResult && newStamps.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: 'spring', damping: 15 }}
              className="bg-[#1a0d00] border border-[#F4A300]/40 rounded-2xl p-6 w-full max-w-sm text-center"
            >
              <Trophy size={40} className="text-[#F4A300] mx-auto mb-3" />
              <h3 className="text-xl font-black text-[#FFF3DC] mb-1">¡Sobre abierto!</h3>
              <p className="text-sm text-[#FFF3DC]/50 mb-4">Obtuviste estas estampas:</p>
              <div className="flex justify-center gap-4 mb-4 flex-wrap">
                {newStamps.map((s) => (
                  <div key={s.id} className="flex flex-col items-center gap-1">
                    {s.icon.startsWith('http') ? (
                      <img src={s.icon} alt={s.name} className="w-12 h-12 object-contain" />
                    ) : (
                      <span className="text-4xl">{s.icon}</span>
                    )}
                    <span className="text-[10px] text-[#FFF3DC]/60">{s.name}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-[#FFF3DC]/40 mb-4">
                Puntos restantes:{' '}
                <strong className="text-[#F4A300]">{pointBalance}</strong>
              </p>
              <button
                onClick={handleCloseResult}
                className="w-full py-3 bg-[#C1121F] text-white rounded-xl font-black text-sm"
              >
                ¡Genial!
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, QrCode, CheckCircle, XCircle, RefreshCw, Zap } from 'lucide-react'
import { Html5Qrcode, Html5QrcodeScannerState } from 'html5-qrcode'
import { motion, AnimatePresence } from 'framer-motion'
import { api } from '../../services/api'
import { usePassportStore } from '../../store/passportStore'

type CheckinStatus = 'idle' | 'scanning' | 'processing' | 'success' | 'error'

interface CheckinResult {
  business: {
    id: string
    name: string
    category: string
  }
  points_earned: number
  stamp_earned?: {
    icon: string   // campo `icon` igual que tu Stamp del store
    name: string
    rarity?: string
  }
  point_balance: number   // saldo actualizado que devuelve el servidor
  message: string
  already_checked_in?: boolean
}

const QR_READER_ID   = 'qr-reader-garnacha'
const SCAN_COOLDOWN  = 2000

export default function CheckinPage() {
  const navigate = useNavigate()

  // ← usa pointBalance y setPointBalance del store existente
  const { pointBalance, setPointBalance } = usePassportStore()

  const [status, setStatus]                 = useState<CheckinStatus>('idle')
  const [result, setResult]                 = useState<CheckinResult | null>(null)
  const [error, setError]                   = useState<string | null>(null)
  const [cameraPermission, setCameraPermission] = useState<'unknown' | 'granted' | 'denied'>('unknown')

  const scannerRef  = useRef<Html5Qrcode | null>(null)
  const lastScanRef = useRef<number>(0)

  useEffect(() => {
    return () => { stopScanner() }
  }, [])

  async function startScanner() {
    setStatus('scanning')
    setError(null)
    try {
      const scanner = new Html5Qrcode(QR_READER_ID)
      scannerRef.current = scanner
      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 240, height: 240 }, aspectRatio: 1, disableFlip: false },
        onScanSuccess,
        undefined
      )
      setCameraPermission('granted')
    } catch (err: any) {
      setCameraPermission('denied')
      setStatus('error')
      setError(
        err?.message?.includes('Permission')
          ? 'Necesitamos acceso a tu cámara para escanear el QR.'
          : 'No se pudo iniciar la cámara. Intenta de nuevo.'
      )
    }
  }

  async function stopScanner() {
    if (
      scannerRef.current &&
      scannerRef.current.getState() === Html5QrcodeScannerState.SCANNING
    ) {
      try {
        await scannerRef.current.stop()
        scannerRef.current.clear()
      } catch (_) {}
    }
    scannerRef.current = null
  }

  async function onScanSuccess(decodedText: string) {
    const now = Date.now()
    if (now - lastScanRef.current < SCAN_COOLDOWN) return
    lastScanRef.current = now

    await stopScanner()
    setStatus('processing')

    try {
      // El QR puede ser un token crudo o una URL con ?token=
      let token = decodedText
      try {
        const url = new URL(decodedText)
        token = url.searchParams.get('token') ?? decodedText
      } catch (_) {}

      const res = await api.post<CheckinResult>('/api/v1/checkins', { token })
      setResult(res.data)

      // ← actualiza el saldo usando el valor que devuelve el servidor
      setPointBalance(res.data.point_balance)

      setStatus('success')
    } catch (err: any) {
      const msg =
        err?.response?.data?.message ??
        'No pudimos registrar tu check-in. Intenta de nuevo.'
      setError(msg)
      setStatus('error')
    }
  }

  function resetScan() {
    setStatus('idle')
    setResult(null)
    setError(null)
  }

  return (
    <div className="min-h-screen bg-[#110800] text-[#FFF3DC] flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#110800]/95 backdrop-blur border-b border-[#2a1800] px-4 pt-4 pb-3 flex items-center justify-between">
        <button
          onClick={async () => { await stopScanner(); navigate(-1) }}
          className="p-2 -ml-2 text-[#FFF3DC]/60 hover:text-[#FFF3DC] transition-colors"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-base font-black text-[#FFF3DC]">Check-in QR</h1>
        <div className="w-8" />
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-4 py-6 gap-6">
        <AnimatePresence mode="wait">

          {/* IDLE */}
          {status === 'idle' && (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center gap-6 text-center"
            >
              <div className="w-40 h-40 border-2 border-dashed border-[#3d2200] rounded-2xl flex items-center justify-center">
                <QrCode size={64} className="text-[#3d2200]" />
              </div>
              <div>
                <h2 className="text-xl font-black text-[#FFF3DC] mb-2">Escanea el QR del local</h2>
                <p className="text-sm text-[#FFF3DC]/50 leading-relaxed max-w-xs">
                  Apunta tu cámara al código QR del negocio para registrar tu visita y ganar puntos.
                </p>
              </div>
              <button
                onClick={startScanner}
                className="flex items-center gap-2 px-8 py-4 bg-[#C1121F] text-white rounded-2xl font-black text-base active:scale-95 transition-all shadow-[0_4px_20px_rgba(193,18,31,0.3)]"
              >
                <QrCode size={20} />
                Abrir cámara
              </button>
            </motion.div>
          )}

          {/* SCANNING */}
          {status === 'scanning' && (
            <motion.div
              key="scanning"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-4 w-full max-w-xs"
            >
              <p className="text-sm text-[#FFF3DC]/60">Apunta al código QR del negocio</p>
              <div className="relative w-full aspect-square rounded-2xl overflow-hidden border-2 border-[#C1121F]/50">
                <div id={QR_READER_ID} className="w-full h-full" />
                {/* Corner decorators */}
                {[
                  'top-0 left-0 border-t-2 border-l-2 rounded-tl-lg',
                  'top-0 right-0 border-t-2 border-r-2 rounded-tr-lg',
                  'bottom-0 left-0 border-b-2 border-l-2 rounded-bl-lg',
                  'bottom-0 right-0 border-b-2 border-r-2 rounded-br-lg',
                ].map((cls, i) => (
                  <div key={i} className={`absolute w-6 h-6 border-[#C1121F] ${cls}`} />
                ))}
                <div className="absolute inset-x-0 h-0.5 bg-[#C1121F]/60 animate-scan-line" />
              </div>
              <button
                onClick={async () => { await stopScanner(); resetScan() }}
                className="text-sm text-[#FFF3DC]/40 hover:text-[#FFF3DC] transition-colors"
              >
                Cancelar
              </button>
            </motion.div>
          )}

          {/* PROCESSING */}
          {status === 'processing' && (
            <motion.div
              key="processing"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-4"
            >
              <RefreshCw size={48} className="text-[#C1121F] animate-spin" />
              <p className="text-sm text-[#FFF3DC]/60">Registrando tu visita…</p>
            </motion.div>
          )}

          {/* SUCCESS */}
          {status === 'success' && result && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
              transition={{ type: 'spring', damping: 15 }}
              className="flex flex-col items-center gap-4 text-center w-full max-w-xs"
            >
              <div className="w-20 h-20 rounded-full bg-[#2D6A4F]/20 border-2 border-[#2D6A4F] flex items-center justify-center">
                <CheckCircle size={40} className="text-[#2D6A4F]" />
              </div>
              <div>
                <h2 className="text-xl font-black text-[#FFF3DC] mb-1">
                  {result.already_checked_in ? '¡Ya estuviste aquí!' : '¡Check-in exitoso!'}
                </h2>
                <p className="text-sm text-[#FFF3DC]/50">{result.business.name}</p>
              </div>

              {result.points_earned > 0 && (
                <div className="flex items-center gap-2 px-4 py-2 bg-[#F4A300]/10 border border-[#F4A300]/30 rounded-full">
                  <Zap size={16} className="text-[#F4A300]" fill="#F4A300" />
                  <span className="text-sm font-black text-[#F4A300]">+{result.points_earned} puntos</span>
                </div>
              )}

              {result.stamp_earned && (
                <div className="bg-[#1a0d00] border border-[#3d2200] rounded-2xl p-4 flex flex-col items-center gap-2 w-full">
                  <p className="text-xs text-[#FFF3DC]/40">¡Estampa obtenida!</p>
                  {result.stamp_earned.icon.startsWith('http') ? (
                    <img src={result.stamp_earned.icon} alt={result.stamp_earned.name} className="w-14 h-14 object-contain" />
                  ) : (
                    <span className="text-5xl">{result.stamp_earned.icon}</span>
                  )}
                  <p className="text-sm font-black text-[#FFF3DC]">{result.stamp_earned.name}</p>
                  {result.stamp_earned.rarity && (
                    <span className="text-xs font-bold capitalize text-[#F4A300]">
                      {result.stamp_earned.rarity}
                    </span>
                  )}
                </div>
              )}

              <p className="text-xs text-[#FFF3DC]/30">
                Total: <strong className="text-[#FFF3DC]/60">{pointBalance} pts</strong>
              </p>

              <div className="flex gap-3 w-full">
                <button
                  onClick={resetScan}
                  className="flex-1 py-3 bg-[#1a0d00] border border-[#2a1800] rounded-xl text-sm font-bold text-[#FFF3DC]/60"
                >
                  Otro escaneo
                </button>
                <button
                  onClick={() => navigate(`/business/${result.business.id}`)}
                  className="flex-1 py-3 bg-[#C1121F] rounded-xl text-sm font-black text-white"
                >
                  Ver negocio
                </button>
              </div>
            </motion.div>
          )}

          {/* ERROR */}
          {status === 'error' && (
            <motion.div
              key="error"
              initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-4 text-center max-w-xs"
            >
              <div className="w-20 h-20 rounded-full bg-[#C1121F]/20 border-2 border-[#C1121F] flex items-center justify-center">
                <XCircle size={40} className="text-[#C1121F]" />
              </div>
              <div>
                <h2 className="text-xl font-black text-[#FFF3DC] mb-1">Algo salió mal</h2>
                <p className="text-sm text-[#FFF3DC]/50 leading-relaxed">{error}</p>
              </div>
              <button
                onClick={async () => {
                  resetScan()
                  if (cameraPermission !== 'denied') await startScanner()
                }}
                className="flex items-center gap-2 px-6 py-3 bg-[#C1121F] rounded-xl font-black text-sm text-white active:scale-95 transition-all"
              >
                <RefreshCw size={16} />
                Intentar de nuevo
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Contenedor del QR — oculto cuando no se usa */}
      {status !== 'scanning' && (
        <div id={QR_READER_ID} className="hidden" aria-hidden />
      )}
    </div>
  )
}
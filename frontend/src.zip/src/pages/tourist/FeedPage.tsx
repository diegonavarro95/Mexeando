import { useEffect, useState, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, RefreshCw, Flame, Star, Clock } from 'lucide-react'
import ReviewCard, { type Review } from '../../components/ReviewCard'
import { api } from '../../services/api'

type FeedFilter = 'recent' | 'popular' | 'friends'

interface FeedResponse {
  reviews: Review[]
  nextCursor?: string
  hasMore: boolean
}

export default function FeedPage() {
  const navigate = useNavigate()
  const [reviews, setReviews]         = useState<Review[]>([])
  const [loading, setLoading]         = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [filter, setFilter]           = useState<FeedFilter>('recent')
  const [cursor, setCursor]           = useState<string | undefined>()
  const [hasMore, setHasMore]         = useState(true)
  const [refreshing, setRefreshing]   = useState(false)
  const loaderRef = useRef<HTMLDivElement | null>(null)

  const fetchFeed = useCallback(
    async (reset = false) => {
      if (reset) {
        setLoading(true)
        setCursor(undefined)
      } else {
        setLoadingMore(true)
      }
      try {
        const params: Record<string, string> = { filter }
        if (!reset && cursor) params.cursor = cursor
        const res = await api.get<FeedResponse>('/api/v1/feed', { params })
        setReviews((prev) => (reset ? res.data.reviews : [...prev, ...res.data.reviews]))
        setCursor(res.data.nextCursor)
        setHasMore(res.data.hasMore)
      } catch (err) {
        console.error('Feed error:', err)
      } finally {
        setLoading(false)
        setLoadingMore(false)
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [filter]
  )

  useEffect(() => {
    fetchFeed(true)
  }, [filter]) // eslint-disable-line react-hooks/exhaustive-deps

  // Infinite scroll
  useEffect(() => {
    if (!loaderRef.current) return
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loadingMore && !loading) {
          fetchFeed(false)
        }
      },
      { threshold: 0.5 }
    )
    observer.observe(loaderRef.current)
    return () => observer.disconnect()
  }, [fetchFeed, hasMore, loadingMore, loading])

  async function handleLike(id: string) {
    await api.post(`/api/v1/reviews/${id}/like`)
  }

  async function handleRefresh() {
    setRefreshing(true)
    await fetchFeed(true)
    setRefreshing(false)
  }

  const filterConfig: { id: FeedFilter; label: string; icon: React.ReactNode }[] = [
    { id: 'recent',  label: 'Recientes',  icon: <Clock size={13} /> },
    { id: 'popular', label: 'Populares',  icon: <Flame size={13} /> },
    { id: 'friends', label: 'Amigos',     icon: <Star  size={13} /> },
  ]

  return (
    <div className="min-h-screen bg-[#110800] text-[#FFF3DC]">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#110800]/95 backdrop-blur border-b border-[#2a1800] px-4 pt-4 pb-3">
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 text-[#FFF3DC]/60 hover:text-[#FFF3DC] transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-base font-black text-[#FFF3DC] tracking-tight">Feed de Garnachas</h1>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 -mr-2 text-[#FFF3DC]/60 hover:text-[#FFF3DC] transition-colors"
          >
            <RefreshCw size={18} className={refreshing ? 'animate-spin' : ''} />
          </button>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2">
          {filterConfig.map(({ id, label, icon }) => (
            <button
              key={id}
              onClick={() => setFilter(id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all duration-200 ${
                filter === id
                  ? 'bg-[#C1121F] text-white'
                  : 'bg-[#1a0d00] text-[#FFF3DC]/50 border border-[#2a1800]'
              }`}
            >
              {icon}
              {label}
            </button>
          ))}
        </div>
      </header>

      <main className="pb-24">
        {loading ? (
          <div className="space-y-3 px-4 py-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-[#150900] border border-[#2a1800] rounded-2xl h-40 animate-pulse" />
            ))}
          </div>
        ) : reviews.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
            <span className="text-5xl mb-4">🌮</span>
            <p className="text-[#FFF3DC]/60 text-sm">No hay reseñas aquí todavía.</p>
            <p className="text-[#FFF3DC]/30 text-xs mt-1">¡Sé el primero en reseñar una garnacha!</p>
          </div>
        ) : (
          <div className="px-4 py-4 space-y-3">
            {reviews.map((review) => (
              <ReviewCard key={review.id} review={review} onLike={handleLike} />
            ))}
            <div ref={loaderRef} className="flex justify-center py-4">
              {loadingMore && <RefreshCw size={20} className="animate-spin text-[#C1121F]" />}
              {!hasMore && reviews.length > 0 && (
                <p className="text-xs text-[#FFF3DC]/30">Has llegado al final 🌮</p>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
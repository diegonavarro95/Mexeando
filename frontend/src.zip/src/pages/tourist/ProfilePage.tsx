import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  ArrowLeft, Heart, Star, MapPin, QrCode,
  BookOpen, LogOut, RefreshCw, ChevronRight, Trophy,
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { usePassportStore } from '../../store/passportStore'
import { api } from '../../services/api'
import PointsCounter from '../../components/PointsCounter'

interface FavoriteBusiness {
  id: string
  name: string
  category: string
  address: string
  photoUrl?: string
  rating: number
  reviewCount: number
}

interface UserStats {
  checkIns: number
  reviews: number
  stampsObtained: number
  level: number
  levelName: string
  nextLevelPoints: number
  currentLevelPoints: number
}

export default function ProfilePage() {
  const navigate      = useNavigate()
const { displayName, clearAuth } = useAuthStore()

  // ← usa pointBalance del store existente
  const { pointBalance, resetPassport } = usePassportStore()

  const [favorites, setFavorites]   = useState<FavoriteBusiness[]>([])
  const [stats, setStats]           = useState<UserStats | null>(null)
  const [loadingFavs, setLoadingFavs]   = useState(true)
  const [loadingStats, setLoadingStats] = useState(true)
  const [activeTab, setActiveTab]   = useState<'favorites' | 'stats'>('favorites')

  useEffect(() => {
    loadFavorites()
    loadStats()
  }, [])

  async function loadFavorites() {
    setLoadingFavs(true)
    try {
      const res = await api.get<{ favorites: FavoriteBusiness[] }>('/api/v1/favorites')
      setFavorites(res.data.favorites)
    } catch (err) {
      console.error('Favorites error:', err)
    } finally {
      setLoadingFavs(false)
    }
  }

  async function loadStats() {
    setLoadingStats(true)
    try {
      const res = await api.get<{ stats: UserStats }>('/api/v1/users/me/stats')
      setStats(res.data.stats)
    } catch (err) {
      console.error('Stats error:', err)
    } finally {
      setLoadingStats(false)
    }
  }

  async function handleRemoveFavorite(id: string) {
    await api.delete(`/api/v1/favorites/${id}`)
    setFavorites((prev) => prev.filter((f) => f.id !== id))
  }

  async function handleLogout() {
    resetPassport()   // limpia el store de pasaporte
    clearAuth()
  }

  const initials = displayName
    ? displayName.split(' ').map((w: string) => w[0]).slice(0, 2).join('').toUpperCase()
    : '?'

  const levelPct = stats
    ? Math.round(
        ((pointBalance - stats.currentLevelPoints) /
          (stats.nextLevelPoints - stats.currentLevelPoints)) * 100
      )
    : 0

  return (
    <div className="min-h-screen bg-[#110800] text-[#FFF3DC]">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#110800]/95 backdrop-blur border-b border-[#2a1800] px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 text-[#FFF3DC]/60 hover:text-[#FFF3DC] transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-base font-black text-[#FFF3DC]">Mi Perfil</h1>
          <button
            onClick={handleLogout}
            className="p-2 -mr-2 text-[#FFF3DC]/40 hover:text-[#C1121F] transition-colors"
          >
            <LogOut size={18} />
          </button>
        </div>
      </header>

      <main className="pb-24">
        {/* Profile Hero */}
        <div className="px-4 py-6 flex flex-col items-center text-center">
          <div className="w-20 h-20 rounded-full bg-[#C1121F]/20 border-2 border-[#C1121F] flex items-center justify-center text-2xl font-black text-[#C1121F] mb-3 overflow-hidden">
            {
              initials
        }
          </div>
          <h2 className="text-xl font-black text-[#FFF3DC]">{displayName || 'Turista'}</h2>
          <p className="text-xs text-[#FFF3DC]/40 mt-0.5">Turista</p>

          <div className="flex items-center gap-2 mt-3 flex-wrap justify-center">
            <PointsCounter points={pointBalance} size="md" />
            {stats && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#2D6A4F]/20 border border-[#2D6A4F]/40 rounded-full">
                <Trophy size={14} className="text-[#2D6A4F]" />
                <span className="text-xs font-bold text-[#2D6A4F]">
                  Nv. {stats.level} · {stats.levelName}
                </span>
              </div>
            )}
          </div>

          {/* Level progress */}
          {stats && (
            <div className="w-full mt-4 px-2">
              <div className="flex items-center justify-between text-[10px] text-[#FFF3DC]/40 mb-1">
                <span>Nivel {stats.level}</span>
                <span>{pointBalance}/{stats.nextLevelPoints} pts</span>
              </div>
              <div className="w-full h-1.5 bg-[#1a0d00] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#2D6A4F] rounded-full transition-all duration-700"
                  style={{ width: `${Math.min(levelPct, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Quick actions */}
        <div className="px-4 grid grid-cols-2 gap-2 mb-4">
          {[
            {
              icon: <QrCode size={20} />,
              label: 'Check-in QR',
              sub: 'Escanear local',
              to: '/checkin',
              accent: 'border-[#C1121F]/40 bg-[#C1121F]/10',
              iconColor: 'text-[#C1121F]',
            },
            {
              icon: <BookOpen size={20} />,
              label: 'Mi Pasaporte',
              sub: 'Ver estampas',
              to: '/passport',
              accent: 'border-[#F4A300]/40 bg-[#F4A300]/10',
              iconColor: 'text-[#F4A300]',
            },
          ].map((action) => (
            <button
              key={action.to}
              onClick={() => navigate(action.to)}
              className={`flex items-center gap-3 p-3 rounded-xl border ${action.accent} active:scale-95 transition-all`}
            >
              <span className={action.iconColor}>{action.icon}</span>
              <div className="text-left">
                <p className="text-sm font-bold text-[#FFF3DC]">{action.label}</p>
                <p className="text-[10px] text-[#FFF3DC]/40">{action.sub}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Stats pills */}
        {!loadingStats && stats && (
          <div className="px-4 grid grid-cols-3 gap-2 mb-4">
            {[
              { label: 'Check-ins', value: stats.checkIns,       emoji: '📍' },
              { label: 'Reseñas',   value: stats.reviews,        emoji: '⭐' },
              { label: 'Estampas',  value: stats.stampsObtained, emoji: '🎴' },
            ].map((s) => (
              <div
                key={s.label}
                className="bg-[#1a0d00] border border-[#2a1800] rounded-xl p-3 flex flex-col items-center gap-1"
              >
                <span className="text-xl leading-none">{s.emoji}</span>
                <span className="text-lg font-black text-[#FFF3DC]">{s.value}</span>
                <span className="text-[10px] text-[#FFF3DC]/40">{s.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="px-4 flex gap-2 mb-4">
          {(['favorites', 'stats'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-sm font-bold transition-all duration-200 ${
                activeTab === tab
                  ? 'bg-[#C1121F] text-white'
                  : 'bg-[#1a0d00] text-[#FFF3DC]/50 border border-[#2a1800]'
              }`}
            >
              {tab === 'favorites' ? '❤️ Favoritos' : '📈 Actividad'}
            </button>
          ))}
        </div>

        {activeTab === 'favorites' ? (
          <div className="px-4">
            {loadingFavs ? (
              <div className="space-y-2">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-20 bg-[#150900] border border-[#2a1800] rounded-xl animate-pulse" />
                ))}
              </div>
            ) : favorites.length === 0 ? (
              <div className="flex flex-col items-center py-12 text-center">
                <Heart size={36} className="text-[#FFF3DC]/20 mb-3" />
                <p className="text-sm text-[#FFF3DC]/40">Aún no tienes favoritos</p>
                <button
                  onClick={() => navigate('/explore')}
                  className="mt-3 text-xs text-[#C1121F] font-semibold"
                >
                  Explorar garnachas →
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {favorites.map((biz) => (
                  <div
                    key={biz.id}
                    className="bg-[#150900] border border-[#2a1800] rounded-xl overflow-hidden flex items-center gap-3 p-3"
                  >
                    {biz.photoUrl ? (
                      <img src={biz.photoUrl} alt={biz.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                    ) : (
                      <div className="w-14 h-14 rounded-lg bg-[#2a1800] flex items-center justify-center text-2xl shrink-0">
                        🌮
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-[#FFF3DC] truncate">{biz.name}</p>
                      <p className="text-[10px] text-[#FFF3DC]/40 flex items-center gap-1">
                        <MapPin size={9} /> {biz.address}
                      </p>
                      <div className="flex items-center gap-1 mt-0.5">
                        <Star size={10} fill="#F4A300" className="text-[#F4A300]" />
                        <span className="text-[10px] text-[#FFF3DC]/60">
                          {biz.rating.toFixed(1)} · {biz.reviewCount} reseñas
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <button
                        onClick={() => navigate(`/business/${biz.id}`)}
                        className="p-1.5 text-[#FFF3DC]/30 hover:text-[#FFF3DC] transition-colors"
                      >
                        <ChevronRight size={16} />
                      </button>
                      <button
                        onClick={() => handleRemoveFavorite(biz.id)}
                        className="p-1.5 text-[#FFF3DC]/30 hover:text-[#C1121F] transition-colors"
                      >
                        <Heart size={14} fill="currentColor" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="px-4">
            {loadingStats ? (
              <div className="flex justify-center py-8">
                <RefreshCw size={20} className="animate-spin text-[#C1121F]" />
              </div>
            ) : (
              <div className="bg-[#1a0d00] border border-[#2a1800] rounded-xl p-4 text-center">
                <p className="text-sm text-[#FFF3DC]/40">
                  El historial detallado estará disponible próximamente.
                </p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
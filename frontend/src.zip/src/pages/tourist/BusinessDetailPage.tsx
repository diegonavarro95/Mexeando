/**
 * src/pages/tourist/BusinessDetailPage.tsx
 * T-2 — Detalle del negocio
 * Ruta: /business/:id
 *
 * Spec §02 T-2:
 *  - Imagen principal (is_primary=true va primero)
 *  - Nombre, tipo (category_slug), ciudad
 *  - Stats: avg_rating, distance_m, precio (modal)
 *  - Tags: idiomas, accepts_card, badge "Popular" si checkin_count > 500
 *  - Sección "Especialidades": menu_items ordenados por sort_order
 *  - Sección "Descripción": translated_description si existe, si no description
 *  - Sección "Reseñas recientes": últimas 5 con rating, body, display_name, created_at
 *  - Botón "Cómo llegar" → Google Maps lat/lng
 *  - Botón "Chat IA" → /chat/:businessId
 *  - GET /api/v1/businesses/:id?lang={preferred_lang}
 */

import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api }          from '../../services/api';
import { useAuthStore } from '../../store/authStore';
import StarRating       from '../../components/ui/StarRating';
import OlaBadge         from '../../components/ui/OlaBadge';
import BottomNav        from '../../components/ui/BottomNav';

// ─── Tipos (espejo de qBusinessDetail del backend) ────────────────────────────

interface MenuItem {
  id: string;
  name: string;
  price: number | null;
  icon: string | null;
  sort_order: number;
}

interface Review {
  id: string;
  rating: number;
  body: string | null;
  language: string;
  created_at: string;
  profile: { display_name: string; avatar_url: string | null };
}

interface BusinessDetail {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  translated_description: string | null;
  category_slug: string;
  category_icon: string;
  address: string;
  city: string;
  phone: string | null;
  website: string | null;
  accepts_card: boolean;
  ola_verified: boolean;
  avg_rating: number;
  review_count: number;
  checkin_count: number;
  schedule: Record<string, string[] | null> | null;
  lat?: number;
  lng?: number;
  images: { id: string; storage_path: string; is_primary: boolean; sort_order: number }[];
  menu_items: MenuItem[];
  recent_reviews: Review[];
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatDate(iso: string): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60)   return `hace ${mins} min`;
  const hrs = Math.floor(mins / 60);
  if (hrs  < 24)   return `hace ${hrs}h`;
  const days = Math.floor(hrs / 24);
  return `hace ${days}d`;
}

function getImageUrl(path: string): string {
  if (path.startsWith('http')) return path;
  const base = import.meta.env.VITE_SUPABASE_URL;
  return base ? `${base}/storage/v1/object/public/business-images/${path}` : path;
}

// ─── Componente ───────────────────────────────────────────────────────────────

export default function BusinessDetailPage() {
  const { id }         = useParams<{ id: string }>();
  const navigate       = useNavigate();
  const preferredLang  = useAuthStore((s) => s.preferredLang);

  const [business, setBusiness]   = useState<BusinessDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [imgIndex, setImgIndex]   = useState(0);
  const [isFav, setIsFav]         = useState(false);

  // ── Fetch ────────────────────────────────────────────────────────────────────

  useEffect(() => {
    if (!id) return;
    setIsLoading(true);

    api.get<{ data: BusinessDetail }>(`/api/v1/businesses/${id}`, {
      params: { lang: preferredLang },
    })
      .then(({ data }) => {
        const biz = data.data;
        // Ordena imágenes: is_primary primero
        biz.images = [...biz.images].sort((a, b) =>
          Number(b.is_primary) - Number(a.is_primary)
        );
        setBusiness(biz);
      })
      .catch(() => setError('Este negocio no está disponible.'))
      .finally(() => setIsLoading(false));
  }, [id, preferredLang]);

  // ── Toggle favorito ──────────────────────────────────────────────────────────
  const toggleFav = async () => {
    if (!id) return;
    try {
      if (isFav) {
        await api.delete(`/api/v1/favorites/${id}`);
      } else {
        await api.post(`/api/v1/favorites`, { business_id: id });
      }
      setIsFav(!isFav);
    } catch {}
  };

  // ── Loading ──────────────────────────────────────────────────────────────────

  if (isLoading) {
    return (
      <div className="min-h-screen bg-bgDark flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-crema/20 border-t-rojo rounded-full animate-spin" />
      </div>
    );
  }

  // ── Error ────────────────────────────────────────────────────────────────────

  if (error || !business) {
    return (
      <div className="min-h-screen bg-bgDark flex flex-col items-center justify-center gap-4 px-8 text-center">
        <span className="text-5xl">😕</span>
        <p className="text-crema font-bold text-lg">Este negocio no está disponible</p>
        <p className="text-crema/50 text-sm">{error}</p>
        <button
          onClick={() => navigate('/explore')}
          className="bg-rojo text-crema px-6 py-2.5 rounded-full font-bold text-sm
                     hover:bg-rojo/90 active:scale-95 transition-all"
        >
          Volver al mapa
        </button>
      </div>
    );
  }

  const description = business.translated_description ?? business.description ?? '';
  const primaryImg  = business.images[imgIndex];
  const hasImages   = business.images.length > 0;

  const googleMapsUrl = business.lat && business.lng
    ? `https://www.google.com/maps/dir/?api=1&destination=${business.lat},${business.lng}`
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.address + ' ' + business.city)}`;

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-bgDark pb-20">

      {/* ── Hero imagen ── */}
      <div className="relative h-56 bg-crema/5">
        {hasImages ? (
          <img
            src={getImageUrl(primaryImg.storage_path)}
            alt={business.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-7xl">
            {business.category_icon}
          </div>
        )}

        {/* Gradiente bottom */}
        <div className="absolute inset-x-0 bottom-0 h-24
                        bg-gradient-to-t from-bgDark to-transparent" />

        {/* Botones sobre la imagen */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-full bg-bgDark/70 backdrop-blur-sm
                       flex items-center justify-center text-crema
                       hover:bg-bgDark active:scale-90 transition-all"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button
            onClick={toggleFav}
            className="w-9 h-9 rounded-full bg-bgDark/70 backdrop-blur-sm
                       flex items-center justify-center
                       hover:bg-bgDark active:scale-90 transition-all"
          >
            <svg className={`w-5 h-5 ${isFav ? 'text-rojo fill-rojo' : 'text-crema/70'}`}
              fill={isFav ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </button>
        </div>

        {/* Dots de imágenes */}
        {business.images.length > 1 && (
          <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-1.5">
            {business.images.map((_, i) => (
              <button
                key={i}
                onClick={() => setImgIndex(i)}
                className={`w-1.5 h-1.5 rounded-full transition-all
                  ${i === imgIndex ? 'bg-crema w-4' : 'bg-crema/40'}`}
              />
            ))}
          </div>
        )}
      </div>

      {/* ── Contenido ── */}
      <div className="px-4 -mt-4 relative z-10 flex flex-col gap-5">

        {/* Nombre + badges */}
        <div>
          <div className="flex items-start justify-between gap-2">
            <h1 className="text-crema text-2xl font-bold leading-tight flex-1">
              {business.name}
            </h1>
            {business.ola_verified && <OlaBadge />}
          </div>
          <p className="text-amarillo text-xs font-bold uppercase tracking-widest mt-1">
            {business.category_slug} · {business.city.toUpperCase()}
          </p>
        </div>

        {/* ── Stats: rating, distancia, precio ── */}
        <div className="grid grid-cols-3 gap-2">
          <StatCard>
            <StarRating rating={business.avg_rating} size="sm" showNumber={false} />
            <p className="text-crema font-bold text-lg leading-none">
              {business.avg_rating.toFixed(1)}
            </p>
            <p className="text-crema/40 text-[10px]">Rating</p>
          </StatCard>

          <StatCard>
            <span className="text-crema/60 text-xl">📍</span>
            <p className="text-crema font-bold text-lg leading-none">—</p>
            <p className="text-crema/40 text-[10px]">Distancia</p>
          </StatCard>

          <StatCard>
            <span className="text-crema/60 text-xl">💵</span>
            <p className="text-crema font-bold text-lg leading-none">$$</p>
            <p className="text-crema/40 text-[10px]">Precio</p>
          </StatCard>
        </div>

        {/* ── Tags ── */}
        <div className="flex flex-wrap gap-2">
          {/* Idiomas de atención — placeholder, la spec no especifica campo directo */}
          <Tag label="ES" />
          <Tag label="EN" />
          {business.accepts_card && <Tag label="Tarjeta" icon="💳" />}
          {business.checkin_count > 500 && (
            <Tag label="Popular" icon="🔥" highlight />
          )}
        </div>

        {/* ── Especialidades ── */}
        {business.menu_items.length > 0 && (
          <section>
            <SectionTitle>Especialidades</SectionTitle>
            <div className="flex gap-3 overflow-x-auto pb-1 [&::-webkit-scrollbar]:hidden">
              {business.menu_items.map((item) => (
                <div
                  key={item.id}
                  className="flex-shrink-0 flex flex-col items-center gap-1.5
                             bg-crema/5 border border-crema/10 rounded-2xl
                             px-4 py-3 min-w-[80px]"
                >
                  <span className="text-2xl">{item.icon ?? '🍽️'}</span>
                  <p className="text-crema text-xs font-semibold text-center leading-tight">
                    {item.name}
                  </p>
                  {item.price !== null && (
                    <p className="text-amarillo text-xs font-bold">
                      ${item.price.toFixed(0)}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ── Descripción ── */}
        {description && (
          <section>
            <SectionTitle>Descripción</SectionTitle>
            <p className="text-crema/70 text-sm leading-relaxed">{description}</p>
          </section>
        )}

        {/* ── Reseñas recientes ── */}
        {business.recent_reviews.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-3">
              <SectionTitle>Reseñas recientes</SectionTitle>
              <span className="text-crema/40 text-xs">{business.review_count} en total</span>
            </div>
            <div className="flex flex-col gap-3">
              {business.recent_reviews.map((review) => (
                <div
                  key={review.id}
                  className="bg-crema/5 border border-crema/10 rounded-2xl px-4 py-3"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      {/* Avatar */}
                      <div className="w-7 h-7 rounded-full bg-rojo/30 flex items-center
                                      justify-center text-crema text-xs font-bold">
                        {review.profile.avatar_url ? (
                          <img
                            src={review.profile.avatar_url}
                            alt=""
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          review.profile.display_name[0]?.toUpperCase()
                        )}
                      </div>
                      <p className="text-crema text-sm font-semibold">
                        {review.profile.display_name}
                      </p>
                    </div>
                    <StarRating rating={review.rating} size="sm" showNumber={false} />
                  </div>
                  {review.body && (
                    <p className="text-crema/60 text-xs leading-relaxed">{review.body}</p>
                  )}
                  <p className="text-crema/30 text-[10px] mt-1.5">
                    {formatDate(review.created_at)}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ── Acciones ── */}
        <div className="grid grid-cols-2 gap-3 pt-2">
          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2
                       bg-rojo text-crema font-bold py-3.5 rounded-full text-sm
                       shadow-[0_4px_20px_rgba(193,18,31,0.4)]
                       hover:bg-rojo/90 active:scale-95 transition-all"
          >
            <span>📍</span>
            Cómo llegar
          </a>
          <button
            onClick={() => navigate(`/chat/${id}`)}
            className="flex items-center justify-center gap-2
                       border border-crema/20 text-crema font-bold py-3.5 rounded-full text-sm
                       bg-crema/5 hover:bg-crema/10 active:scale-95 transition-all"
          >
            <span>🤖</span>
            Chat IA
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}

// ─── Sub-componentes ─────────────────────────────────────────────────────────

function StatCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-crema/5 border border-crema/10 rounded-2xl
                    flex flex-col items-center justify-center gap-1 py-3 px-2">
      {children}
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="text-crema/50 text-xs font-bold uppercase tracking-widest mb-3">
      {children}
    </h2>
  );
}

function Tag({
  label,
  icon,
  highlight = false,
}: {
  label: string;
  icon?: string;
  highlight?: boolean;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold
        ${highlight
          ? 'bg-amarillo/20 border border-amarillo/50 text-amarillo'
          : 'bg-crema/10 border border-crema/15 text-crema/70'}`}
    >
      {icon && <span>{icon}</span>}
      {label}
    </span>
  );
}
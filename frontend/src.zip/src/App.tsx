/**
 * src/App.tsx — actualizado Fase 4
 */
import type { ReactNode } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';

// Auth
import LanguagePage      from './pages/auth/LanguagePage';
import LoginPage         from './pages/auth/LoginPage';
import RegisterStep1Page from './pages/auth/RegisterStep1Page';
import RegisterStep2Page from './pages/auth/RegisterStep2Page';

// Tourist — Fase 3
import ExplorePage        from './pages/tourist/ExplorePage';
import BusinessDetailPage from './pages/tourist/BusinessDetailPage';

// Tourist — Fase 4  ← NUEVO
import PassportPage from './pages/tourist/PassportPage';
import FeedPage     from './pages/tourist/FeedPage';
import ProfilePage  from './pages/tourist/ProfilePage';
import CheckinPage  from './pages/tourist/CheckinPage';

// ─── Guards ───────────────────────────────────────────────────────────────────
function PublicRoute({ children }: { children: ReactNode }) {
  const token = useAuthStore((s) => s.accessToken);
  return token ? <Navigate to="/explore" replace /> : <>{children}</>;
}

function ProtectedRoute({ children }: { children: ReactNode }) {  // ← NUEVO
  const token = useAuthStore((s) => s.accessToken);
  return token ? <>{children}</> : <Navigate to="/login" replace />;
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const isAuthReady = useAuthStore((s) => s.isAuthReady);

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-bgDark flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-crema/20 border-t-rojo rounded-full animate-spin" />
          <p className="text-crema/50 text-sm">Cargando la Ruta...</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Selección de idioma */}
        <Route
          path="/"
          element={
            localStorage.getItem('preferredLang')
              ? <Navigate to="/login" replace />
              : <LanguagePage />
          }
        />

        {/* Auth */}
        <Route path="/login"         element={<PublicRoute><LoginPage /></PublicRoute>} />
        <Route path="/register"      element={<PublicRoute><RegisterStep1Page /></PublicRoute>} />
        <Route path="/register/type" element={<PublicRoute><RegisterStep2Page /></PublicRoute>} />

        {/* Turista — Fase 3 */}
        <Route path="/explore"      element={<ExplorePage />} />
        <Route path="/business/:id" element={<BusinessDetailPage />} />

        {/* Turista — Fase 4  ← REEMPLAZA los placeholders */}
        <Route path="/passport" element={<ProtectedRoute><PassportPage /></ProtectedRoute>} />
        <Route path="/feed"     element={<ProtectedRoute><FeedPage /></ProtectedRoute>} />
        <Route path="/profile"  element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
        <Route path="/checkin"  element={<ProtectedRoute><CheckinPage /></ProtectedRoute>} />

        {/* Placeholder — Fase 4 aún pendiente */}
        <Route path="/chat/:businessId" element={
          <div className="min-h-screen bg-bgDark text-crema flex items-center justify-center font-bold text-xl">
            Chat IA — Fase 4
          </div>
        } />

        {/* Placeholders próximas fases — sin tocar */}
        <Route path="/owner/*" element={
          <div className="min-h-screen bg-bgDark text-crema flex items-center justify-center font-bold text-xl">
            Panel Dueño — Fase 5
          </div>
        } />
        <Route path="/admin/*" element={
          <div className="min-h-screen bg-bgDark text-crema flex items-center justify-center font-bold text-xl">
            Admin — Fase 6
          </div>
        } />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
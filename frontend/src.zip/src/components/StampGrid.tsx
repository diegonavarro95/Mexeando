import { Lock } from 'lucide-react'
import type { StampCollection } from '../store/passportStore'

// Tipo que StampGrid recibe — compatible con el store existente
export type Stamp = StampCollection['stamps'][number] & {
  rarity?: 'common' | 'rare' | 'epic' | 'legendary'
  description?: string
}

interface StampGridProps {
  stamps: Stamp[]
  cols?: 3 | 4 | 5
  showLocked?: boolean
  onStampClick?: (stamp: Stamp) => void
  className?: string
}

const rarityConfig = {
  common: {
    border: 'border-[#3d2200]',
    glow: '',
    badge: 'bg-[#2a1800] text-[#FFF3DC]/50',
    label: 'C',
  },
  rare: {
    border: 'border-[#2D6A4F]/70',
    glow: 'shadow-[0_0_8px_rgba(45,106,79,0.4)]',
    badge: 'bg-[#2D6A4F]/20 text-[#2D6A4F]',
    label: 'R',
  },
  epic: {
    border: 'border-[#C1121F]/70',
    glow: 'shadow-[0_0_10px_rgba(193,18,31,0.4)]',
    badge: 'bg-[#C1121F]/20 text-[#C1121F]',
    label: 'E',
  },
  legendary: {
    border: 'border-[#F4A300]/80',
    glow: 'shadow-[0_0_14px_rgba(244,163,0,0.5)]',
    badge: 'bg-[#F4A300]/20 text-[#F4A300]',
    label: 'L',
  },
}

const colsMap: Record<3 | 4 | 5, string> = {
  3: 'grid-cols-3',
  4: 'grid-cols-4',
  5: 'grid-cols-5',
}

export default function StampGrid({
  stamps,
  cols = 4,
  showLocked = true,
  onStampClick,
  className = '',
}: StampGridProps) {
  const visible = showLocked ? stamps : stamps.filter((s) => s.obtained)

  return (
    <div className={`grid ${colsMap[cols]} gap-2 ${className}`}>
      {visible.map((stamp) => {
        const rarity = stamp.rarity ?? 'common'
        const rCfg = rarityConfig[rarity]
        const isObtained = stamp.obtained

        return (
          <button
            key={stamp.id}
            onClick={() => onStampClick?.(stamp)}
            className={`
              relative flex flex-col items-center justify-center
              aspect-square rounded-xl border p-2
              transition-all duration-200 active:scale-95
              ${isObtained
                ? `${rCfg.border} ${rCfg.glow} bg-[#1a0d00]`
                : 'border-[#2a1800] bg-[#130800]'
              }
              ${onStampClick ? 'cursor-pointer hover:scale-105' : 'cursor-default'}
            `}
          >
            {isObtained ? (
              <>
                {/* icon puede ser emoji o URL */}
                {stamp.icon.startsWith('http') ? (
                  <img src={stamp.icon} alt={stamp.name} className="w-8 h-8 mb-1 object-contain" />
                ) : (
                  <span className="text-2xl leading-none mb-1 select-none">{stamp.icon}</span>
                )}
                <span className="text-[9px] font-bold text-[#FFF3DC]/70 text-center leading-tight truncate w-full">
                  {stamp.name}
                </span>
                <span
                  className={`absolute top-1 right-1 text-[8px] font-bold px-1 py-0.5 rounded-full leading-none ${rCfg.badge}`}
                >
                  {rCfg.label}
                </span>
              </>
            ) : (
              <>
                <Lock size={18} className="text-[#3d2200] mb-1" />
                <span className="text-[9px] text-[#FFF3DC]/20 text-center leading-tight truncate w-full">
                  {stamp.name}
                </span>
              </>
            )}
          </button>
        )
      })}
    </div>
  )
}
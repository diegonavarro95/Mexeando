/**
 * src/components/map/BusinessCard.tsx
 * Spec §05 — usado en T-1 Explorar y T-6 Perfil (favoritos)
 *
 * Props:
 *   business: BusinessMapResult
 *   onPress: () => void
 */

import { useNavigate } from 'react-router-dom';
import type { BusinessMapResult } from '../../store/MapStore';
import StarRating from '../ui/StarRating';
import OlaBadge  from '../ui/OlaBadge';

interface Props {
  business: BusinessMapResult;
  onPress?: () => void;
}

function formatDistance(meters: number): string {
  if (meters < 1000) return `${Math.round(meters)}m`;
  return `${(meters / 1000).toFixed(1)}km`;
}

export default function BusinessCard({ business, onPress }: Props) {
  const navigate = useNavigate();

  const handleClick = () => {
    onPress?.();
    navigate(`/business/${business.id}`);
  };

  return (
    <button
      onClick={handleClick}
      className="w-full flex items-center gap-3 px-4 py-3
                 bg-crema/5 border border-crema/10 rounded-2xl
                 hover:bg-crema/10 hover:border-crema/20
                 active:scale-[0.98] transition-all duration-150 text-left"
    >
      {/* Ícono de categoría */}
      <div className="w-12 h-12 rounded-xl bg-bgDark border border-crema/10
                      flex items-center justify-center text-2xl flex-shrink-0">
        {business.category_icon}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-crema font-bold text-sm truncate">{business.name}</p>
          {business.ola_verified && <OlaBadge />}
        </div>

        <p className="text-amarillo text-xs font-semibold uppercase tracking-wide mt-0.5">
          {business.category_slug}
        </p>

        <div className="flex items-center gap-3 mt-1">
          <StarRating rating={business.avg_rating} size="sm" />
          <span className="text-crema/50 text-xs">·</span>
          <span className="text-crema/50 text-xs">{formatDistance(business.distance_m)}</span>
          <span className="text-crema/50 text-xs">·</span>
          <span className={`text-xs font-semibold ${business.is_open_now ? 'text-verde' : 'text-rojo'}`}>
            {business.is_open_now ? 'Abierto' : 'Cerrado'}
          </span>
        </div>
      </div>

      {/* Chevron */}
      <svg className="w-4 h-4 text-crema/30 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
      </svg>
    </button>
  );
}
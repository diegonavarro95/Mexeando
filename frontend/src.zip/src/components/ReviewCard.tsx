import { useState } from 'react'
import { Heart, MapPin, Clock } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { es } from 'date-fns/locale'

export interface Review {
  id: string
  userId: string
  userName: string
  userAvatar?: string
  businessId: string
  businessName: string
  businessCategory?: string
  rating: number
  comment: string
  photos?: string[]
  likes: number
  likedByMe: boolean
  createdAt: string
  stampEarned?: {
    icon: string   // usa `icon` igual que tu Stamp del store
    name: string
  }
}

interface ReviewCardProps {
  review: Review
  onLike?: (id: string) => void
  compact?: boolean
  className?: string
}

function StarRating({ value, max = 5 }: { value: number; max?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: max }).map((_, i) => (
        <svg
          key={i}
          width="12"
          height="12"
          viewBox="0 0 12 12"
          fill={i < Math.round(value) ? '#F4A300' : 'none'}
          stroke={i < Math.round(value) ? '#F4A300' : '#3d2200'}
          strokeWidth="1.5"
        >
          <polygon points="6,1 7.5,4.5 11,5 8.5,7.5 9.2,11 6,9.2 2.8,11 3.5,7.5 1,5 4.5,4.5" />
        </svg>
      ))}
    </div>
  )
}

function Avatar({ name, src, size = 36 }: { name: string; src?: string; size?: number }) {
  const initials = name
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  if (src) {
    return (
      <img
        src={src}
        alt={name}
        width={size}
        height={size}
        className="rounded-full object-cover border border-[#3d2200]"
        style={{ width: size, height: size }}
      />
    )
  }

  const colors = [
    'bg-[#C1121F]/30 text-[#C1121F]',
    'bg-[#2D6A4F]/30 text-[#2D6A4F]',
    'bg-[#F4A300]/30 text-[#F4A300]',
  ]
  const color = colors[name.charCodeAt(0) % colors.length]

  return (
    <div
      className={`rounded-full flex items-center justify-center font-bold text-xs border border-[#3d2200] ${color}`}
      style={{ width: size, height: size, fontSize: size * 0.33 }}
    >
      {initials}
    </div>
  )
}

export default function ReviewCard({
  review,
  onLike,
  compact = false,
  className = '',
}: ReviewCardProps) {
  const [liked, setLiked]       = useState(review.likedByMe)
  const [likeCount, setLikeCount] = useState(review.likes)
  const [liking, setLiking]     = useState(false)

  const handleLike = async () => {
    if (liking) return
    setLiking(true)
    setLiked((prev) => !prev)
    setLikeCount((prev) => (liked ? prev - 1 : prev + 1))
    try {
      await onLike?.(review.id)
    } catch {
      setLiked((prev) => !prev)
      setLikeCount((prev) => (liked ? prev + 1 : prev - 1))
    } finally {
      setLiking(false)
    }
  }

  const timeAgo = formatDistanceToNow(new Date(review.createdAt), {
    addSuffix: true,
    locale: es,
  })

  return (
    <article
      className={`bg-[#150900] border border-[#2a1800] rounded-2xl overflow-hidden ${className}`}
    >
      {/* Photos */}
      {!compact && review.photos && review.photos.length > 0 && (
        <div className="flex gap-1 p-2 pb-0">
          {review.photos.slice(0, 3).map((photo, i) => (
            <img
              key={i}
              src={photo}
              alt=""
              className="flex-1 h-28 object-cover rounded-lg"
            />
          ))}
        </div>
      )}

      <div className="p-3">
        {/* Header */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2.5">
            <Avatar name={review.userName} src={review.userAvatar} size={compact ? 30 : 36} />
            <div>
              <p className="text-[#FFF3DC] font-bold text-sm leading-tight">{review.userName}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <StarRating value={review.rating} />
                <span className="text-[#FFF3DC]/40 text-[10px] flex items-center gap-0.5">
                  <Clock size={9} />
                  {timeAgo}
                </span>
              </div>
            </div>
          </div>

          {review.stampEarned && (
            <div className="flex items-center gap-1 bg-[#F4A300]/10 border border-[#F4A300]/30 rounded-full px-2 py-1">
              <span className="text-xs leading-none">{review.stampEarned.icon}</span>
              <span className="text-[9px] font-bold text-[#F4A300] hidden sm:block">
                {review.stampEarned.name}
              </span>
            </div>
          )}
        </div>

        {/* Business tag */}
        <div className="flex items-center gap-1 mb-2">
          <MapPin size={10} className="text-[#C1121F]" />
          <span className="text-[10px] text-[#C1121F] font-semibold">{review.businessName}</span>
          {review.businessCategory && (
            <span className="text-[10px] text-[#FFF3DC]/30">· {review.businessCategory}</span>
          )}
        </div>

        {/* Comment */}
        <p className={`text-[#FFF3DC]/80 text-sm leading-relaxed ${compact ? 'line-clamp-2' : ''}`}>
          {review.comment}
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between mt-3 pt-2 border-t border-[#2a1800]">
          <button
            onClick={handleLike}
            className={`flex items-center gap-1.5 text-xs font-semibold transition-all duration-200 active:scale-90
              ${liked ? 'text-[#C1121F]' : 'text-[#FFF3DC]/40 hover:text-[#C1121F]'}`}
          >
            <Heart size={14} fill={liked ? '#C1121F' : 'transparent'} />
            {likeCount > 0 && <span>{likeCount}</span>}
          </button>
        </div>
      </div>
    </article>
  )
}
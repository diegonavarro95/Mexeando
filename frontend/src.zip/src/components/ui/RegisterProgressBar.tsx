/**
 * src/components/ui/RegisterProgressBar.tsx
 *
 * Barra de progreso de 3 pasos para el flujo de registro.
 * Usada en RegisterStep1Page y RegisterStep2Page.
 */

interface Props {
  currentStep: number; // 1-based
  totalSteps: number;
}

export default function RegisterProgressBar({ currentStep, totalSteps }: Props) {
  return (
    <div className="w-full flex items-center gap-2">
      {Array.from({ length: totalSteps }, (_, i) => {
        const step = i + 1;
        const isCompleted = step < currentStep;
        const isActive    = step === currentStep;

        return (
          <div key={step} className="flex items-center gap-2 flex-1">
            {/* Círculo del paso */}
            <div
              className={`
                w-7 h-7 rounded-full flex items-center justify-center
                text-xs font-bold flex-shrink-0 transition-all duration-300
                ${isCompleted
                  ? 'bg-verde text-crema'
                  : isActive
                    ? 'bg-rojo text-crema shadow-[0_0_12px_rgba(193,18,31,0.5)]'
                    : 'bg-crema/10 text-crema/30'}
              `}
            >
              {isCompleted ? (
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              ) : (
                step
              )}
            </div>

            {/* Línea entre pasos (no después del último) */}
            {step < totalSteps && (
              <div className="flex-1 h-0.5 rounded-full overflow-hidden bg-crema/10">
                <div
                  className={`h-full transition-all duration-500
                    ${isCompleted ? 'w-full bg-verde' : 'w-0 bg-rojo'}`}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
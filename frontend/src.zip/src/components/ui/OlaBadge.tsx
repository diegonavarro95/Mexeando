/**
 * src/components/ui/OlaBadge.tsx
 * Spec §05 — badge verde "Ola MX" verificado
 * Solo se renderiza, no requiere props (el padre decide si lo monta)
 */

export default function OlaBadge() {
  return (
    <span
      className="inline-flex items-center gap-1 px-2.5 py-0.5
                 bg-verde/20 border border-verde/50 text-verde
                 rounded-full text-xs font-bold tracking-wide"
    >
      <span className="w-1.5 h-1.5 rounded-full bg-verde" />
      Ola MX
    </span>
  );
}
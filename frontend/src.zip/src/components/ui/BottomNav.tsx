/**
 * src/components/ui/BottomNav.tsx
 * Spec §05 — barra de navegación inferior para todas las pantallas del turista
 * Props: activeTab: string — uno de: 'explore' | 'map' | 'chat' | 'passport' | 'profile'
 */

import { useNavigate, useLocation } from 'react-router-dom';

interface NavItem {
  id: string;
  label: string;
  path: string;
  icon: (active: boolean) => React.ReactNode;
}

const NAV_ITEMS: NavItem[] = [
  {
    id: 'explore',
    label: 'Inicio',
    path: '/explore',
    icon: (active) => (
      <svg className={`w-5 h-5 ${active ? 'text-rojo' : 'text-crema/40'}`} fill={active ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={active ? 0 : 2}
          d={active
            ? 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'
            : 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'}
        />
      </svg>
    ),
  },
  {
    id: 'map',
    label: 'Mapa',
    path: '/explore',
    icon: (active) => (
      <svg className={`w-5 h-5 ${active ? 'text-rojo' : 'text-crema/40'}`} fill={active ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={active ? 0 : 2}
          d={active
            ? 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7'
            : 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7'}
        />
      </svg>
    ),
  },
  {
    id: 'chat',
    label: 'Chat',
    path: '/chat',
    icon: (active) => (
      <svg className={`w-5 h-5 ${active ? 'text-rojo' : 'text-crema/40'}`} fill={active ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={active ? 0 : 2}
          d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
        />
      </svg>
    ),
  },
  {
    id: 'passport',
    label: 'Álbum',
    path: '/passport',
    icon: (active) => (
      <svg className={`w-5 h-5 ${active ? 'text-rojo' : 'text-crema/40'}`} fill={active ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={active ? 0 : 2}
          d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
        />
      </svg>
    ),
  },
  {
    id: 'profile',
    label: 'Perfil',
    path: '/profile',
    icon: (active) => (
      <svg className={`w-5 h-5 ${active ? 'text-rojo' : 'text-crema/40'}`} fill={active ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={active ? 0 : 2}
          d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
        />
      </svg>
    ),
  },
];

interface Props {
  activeTab?: string;
}

export default function BottomNav({ activeTab }: Props) {
  const navigate = useNavigate();
  const location = useLocation();

  // Detecta la tab activa por path si no se pasa explícitamente
  const currentTab = activeTab ?? (() => {
    const path = location.pathname;
    if (path.startsWith('/explore'))  return 'explore';
    if (path.startsWith('/chat'))     return 'chat';
    if (path.startsWith('/passport')) return 'passport';
    if (path.startsWith('/profile'))  return 'profile';
    return 'explore';
  })();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40
                    bg-bgDark/95 backdrop-blur-sm
                    border-t border-crema/10
                    flex items-center justify-around
                    px-2 pb-safe pt-2 h-16">
      {NAV_ITEMS.map((item) => {
        const isActive = currentTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => navigate(item.path)}
            className="flex flex-col items-center gap-0.5 px-3 py-1
                       active:scale-90 transition-transform duration-100"
          >
            {item.icon(isActive)}
            <span className={`text-[10px] font-semibold transition-colors
              ${isActive ? 'text-rojo' : 'text-crema/40'}`}>
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
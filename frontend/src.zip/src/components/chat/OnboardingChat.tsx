import { useState, useEffect, useRef } from 'react'
import garnachin from '../../assets/garnachin.png'

// ————— Tipos —————
interface Message {
  id: number
  from: 'bot' | 'user'
  text: string
  timestamp: string
}

interface Question {
  id: string
  text: string
  inputType: 'text' | 'select' | 'tel'
  options?: string[]
  placeholder?: string
}

// Mapa de categorías a IDs del backend
const CATEGORY_MAP: Record<string, number> = {
  'Comida y bebida': 1,
  'Artesanías': 2,
  'Hospedaje': 3,
  'Tours y experiencias': 4,
  'Otro': 5,
}

const CITY_OPTIONS = [
  { label: 'Ciudad de México', value: 'cdmx' },
  { label: 'Guadalajara', value: 'guadalajara' },
  { label: 'Monterrey', value: 'monterrey' },
]

// ————— Preguntas del onboarding —————
const QUESTIONS: Question[] = [
  {
    id: 'nombre',
    text: '¡Hola! Soy tu asistente de la Ruta de la Garnacha 🌮\n\n¿Cómo se llama tu negocio?',
    inputType: 'text',
    placeholder: 'Ej. Tacos El Güero',
  },
  {
    id: 'tipo',
    text: '¡Qué buen nombre! ¿Qué tipo de negocio es?',
    inputType: 'select',
    options: ['Comida y bebida', 'Artesanías', 'Hospedaje', 'Tours y experiencias', 'Otro'],
  },
  {
    id: 'ciudad',
    text: '¿En qué ciudad está tu negocio?',
    inputType: 'select',
    options: ['Ciudad de México', 'Guadalajara', 'Monterrey'],
  },
  {
    id: 'direccion',
    text: '¿Cuál es la dirección exacta? (colonia, calle y número)',
    inputType: 'text',
    placeholder: 'Ej. Calle Mesones 52, Centro Histórico',
  },
  {
    id: 'telefono',
    text: '¿Cuál es tu número de WhatsApp para que los turistas puedan contactarte?',
    inputType: 'tel',
    placeholder: 'Ej. 55 1234 5678',
  },
  {
    id: 'descripcion',
    text: 'Cuéntame en una frase qué hace especial a tu negocio 🌟',
    inputType: 'text',
    placeholder: 'Ej. Los mejores tacos de canasta desde 1985',
  },
]

const CONFIRM_MESSAGE =
  '¡Perfecto! 🎉 Ya tengo todo lo que necesito. Revisa tu información antes de publicarla, puedes editar cualquier campo.'

const INVALID_BUSINESS_WORDS = [
  "adios", "adiós", "gracias", "ok", "si", "no", "nada", "test", "prueba", "xd", "jaja", "bye", "chao", "hola", "hi", "hey", "hello", "que tal"
].map(w => w.toLowerCase())

// ————— Helpers —————
function now() {
  return new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })
}

function Avatar() {
  return (
    <div style={styles.avatar}>
      <img src={garnachin} alt="Garnachin" style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} />
    </div>
  )
}

function TypingIndicator() {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, marginBottom: 4 }}>
      <Avatar />
      <div style={styles.bubble.bot}>
        <div style={styles.typing}>
          <span style={{ ...styles.dot, animationDelay: '0ms' }} />
          <span style={{ ...styles.dot, animationDelay: '200ms' }} />
          <span style={{ ...styles.dot, animationDelay: '400ms' }} />
        </div>
      </div>
    </div>
  )
}

// ————— Pantalla de confirmación —————
interface ConfirmScreenProps {
  answers: Record<string, string>
  onEdit: (field: string) => void
  onSubmit: () => void
  loading: boolean
  error: string | null
}

const FIELD_LABELS: Record<string, string> = {
  nombre: 'Nombre del negocio',
  tipo: 'Tipo de negocio',
  ciudad: 'Ciudad',
  direccion: 'Dirección',
  telefono: 'WhatsApp',
  descripcion: 'Descripción',
}

const FIELD_ICONS: Record<string, string> = {
  nombre: '🏪',
  tipo: '🍽️',
  ciudad: '🏙️',
  direccion: '📍',
  telefono: '📱',
  descripcion: '✨',
}

function ConfirmScreen({ answers, onEdit, onSubmit, loading, error }: ConfirmScreenProps) {
  return (
    <div style={styles.confirmRoot}>
      <div style={styles.confirmHeader}>
        <span style={{ fontSize: 28 }}>📋</span>
        <div>
          <div style={styles.confirmTitle}>Revisa tu información</div>
          <div style={styles.confirmSubtitle}>Toca cualquier campo para editarlo</div>
        </div>
      </div>

      <div style={styles.confirmCards}>
        {QUESTIONS.map(q => (
          <div key={q.id} style={styles.confirmCard}>
            <div style={styles.confirmCardLeft}>
              <span style={{ fontSize: 20 }}>{FIELD_ICONS[q.id]}</span>
              <div style={{ minWidth: 0 }}>
                <div style={styles.confirmLabel}>{FIELD_LABELS[q.id]}</div>
                <div style={styles.confirmValue}>{answers[q.id] || '—'}</div>
              </div>
            </div>
            <button
              style={styles.editBtn}
              onClick={() => onEdit(q.id)}
              disabled={loading}
            >
              Editar
            </button>
          </div>
        ))}
      </div>

      {error && (
        <div style={styles.errorBox}>
          ⚠️ {error}
        </div>
      )}

      <button
        style={{ ...styles.submitBtn, opacity: loading ? 0.7 : 1 }}
        onClick={onSubmit}
        disabled={loading}
      >
        {loading ? '⏳ Publicando...' : '🚀 Confirmar y publicar'}
      </button>

      <p style={styles.confirmNote}>
        Tu negocio quedará en revisión hasta que un administrador de Garnachin 🌮 lo apruebe.
      </p>
    </div>
  )
}

// ————— Componente principal —————
export default function OnboardingChat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [currentQ, setCurrentQ] = useState(0)
  const [inputValue, setInputValue] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [done, setDone] = useState(false)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [submitLoading, setSubmitLoading] = useState(false)
  const [submitError, setSubmitError] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    showBotMessage(QUESTIONS[0].text, 600)
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isTyping, showConfirm])

  function showBotMessage(text: string, delay = 400) {
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      setMessages(prev => [
        ...prev,
        { id: Date.now(), from: 'bot', text, timestamp: now() },
      ])
      setTimeout(() => inputRef.current?.focus(), 100)
    }, delay + 600)
  }

  function handleSend(value?: string) {
    const answer = (value ?? inputValue).trim()
    if (!answer) return

    const q = QUESTIONS[currentQ]

    // Bug fix: Validar nombre de negocio
    if (q.id === 'nombre') {
      const isInvalid = answer.length < 3 || INVALID_BUSINESS_WORDS.includes(answer.toLowerCase())
      if (isInvalid) {
        setMessages(prev => [...prev, { id: Date.now(), from: 'user', text: answer, timestamp: now() }])
        setInputValue('')
        showBotMessage(
          'Por favor, ingresa un nombre válido para tu negocio (mínimo 3 letras y no una palabra común).',
        )
        return // Mantiene la pregunta actual
      }
    }
    
    setMessages(prev => [...prev, { id: Date.now(), from: 'user', text: answer, timestamp: now() }])
    setInputValue('')

    const newAnswers = { ...answers, [q.id]: answer }
    setAnswers(newAnswers)

    const nextQ = currentQ + 1

    if (nextQ < QUESTIONS.length) {
      setCurrentQ(nextQ)
      showBotMessage(QUESTIONS[nextQ].text)
    } else {
      // Todas las preguntas respondidas → mostrar confirmación
      setIsTyping(true)
      setTimeout(() => {
        setIsTyping(false)
        setMessages(prev => [
          ...prev,
          { id: Date.now(), from: 'bot', text: CONFIRM_MESSAGE, timestamp: now() },
        ])
        setTimeout(() => setShowConfirm(true), 400)
      }, 1200)
    }
  }

  function handleOptionClick(option: string) {
    setInputValue(option)
    inputRef.current?.focus()
  }

  // Editar un campo: regresa al chat en esa pregunta
  function handleEdit(fieldId: string) {
    const idx = QUESTIONS.findIndex(q => q.id === fieldId)
    if (idx === -1) return
    setShowConfirm(false)
    setCurrentQ(idx)
    const label = QUESTIONS[idx].text.split('\n').filter(Boolean).pop() ?? ''
    showBotMessage(`Claro, corrígelo 👇\n${label}`)
  }

  // Enviar al backend
  async function handleSubmit() {
    setSubmitLoading(true)
    setSubmitError(null)

    try {
      const cityValue = CITY_OPTIONS.find(c => c.label === answers.ciudad)?.value ?? 'cdmx'
      const token = localStorage.getItem('accessToken')

      const payload = {
        name: answers.nombre,
        category_id: CATEGORY_MAP[answers.tipo] ?? 5,
        description: answers.descripcion,
        lat: 19.4326,   // TODO: obtener coordenadas reales del GPS
        lng: -99.1332,
        address: answers.direccion,
        city: cityValue,
        phone: answers.telefono,
        accepts_card: false,
      }

      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/v1/businesses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error ?? 'Error al publicar el negocio')
      }

      setShowConfirm(false)
      setDone(true)
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Error inesperado')
    } finally {
      setSubmitLoading(false)
    }
  }

  const question = QUESTIONS[currentQ]

  return (
    <div style={styles.root}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerInner}>
          <Avatar />
          <div>
            <div style={styles.headerName}>Garnachin 🌮</div>
            <div style={styles.headerSub}>
              {showConfirm ? 'Confirmación de datos' : done ? '¡Listo!' : 'En línea'}
            </div>
          </div>
        </div>
        {/* Barra de progreso */}
        {!done && (
          <div style={styles.progressBar}>
            <div
              style={{
                ...styles.progressFill,
                width: showConfirm
                  ? '100%'
                  : `${(currentQ / QUESTIONS.length) * 100}%`,
              }}
            />
          </div>
        )}
      </div>

      {/* Chat */}
      <div style={styles.chatArea}>
        <div style={styles.patternOverlay} />
        <div style={styles.messages}>
          {messages.map(msg => (
            <div
              key={msg.id}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: msg.from === 'user' ? 'flex-end' : 'flex-start',
                marginBottom: 4,
              }}
            >
              {msg.from === 'bot' && (
                <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
                  <Avatar />
                  <div>
                    <div style={styles.bubble.bot}>
                      {msg.text.split('\n').map((line, i, arr) => (
                        <span key={i}>
                          {line}
                          {i < arr.length - 1 && <br />}
                        </span>
                      ))}
                    </div>
                    <div style={styles.timestamp}>{msg.timestamp}</div>
                  </div>
                </div>
              )}
              {msg.from === 'user' && (
                <div>
                  <div style={styles.bubble.user}>{msg.text}</div>
                  <div style={{ ...styles.timestamp, textAlign: 'right' }}>
                    {msg.timestamp} ✓✓
                  </div>
                </div>
              )}
            </div>
          ))}

          {isTyping && <TypingIndicator />}

          {showConfirm && !done && (
            <div style={{ animation: 'fadeIn 0.3s ease', marginTop: 8 }}>
              <ConfirmScreen
                answers={answers}
                onEdit={handleEdit}
                onSubmit={handleSubmit}
                loading={submitLoading}
                error={submitError}
              />
            </div>
          )}

          <div ref={bottomRef} />
        </div>
      </div>

      {/* Input — oculto durante confirmación y al terminar */}
      {!showConfirm && !done && (
        <div style={styles.inputArea}>
          {question.inputType === 'select' && (
            <div style={styles.optionsGrid}>
              {question.options?.map(opt => (
                <button
                  key={opt}
                  style={styles.optionBtn}
                  onClick={() => handleOptionClick(opt)}
                  disabled={isTyping}
                >
                  {opt}
                </button>
              ))}
            </div>
          )}
          {(question.inputType === 'select' || question.inputType === 'text' || question.inputType === 'tel') && (
            <div style={{...styles.inputRow, marginTop: question.inputType === 'select' ? 8 : 0}}>
              <input
                ref={inputRef}
                style={styles.input}
                type={question.inputType === 'select' ? 'text' : question.inputType}
                placeholder={question.placeholder ?? 'Escribe tu respuesta...'}
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                disabled={isTyping}
              />
              <button
                style={{ ...styles.sendBtn, opacity: inputValue.trim() ? 1 : 0.5 }}
                onClick={() => handleSend()}
                disabled={!inputValue.trim() || isTyping}
              >
                <SendIcon />
              </button>
            </div>
          )}
        </div>
      )}

      {done && (
        <div style={styles.doneBar}>
          <span style={{ fontSize: 20 }}>🎉</span>
          <span style={{ color: C.crema, fontWeight: 600 }}>¡Negocio enviado a revisión!</span>
        </div>
      )}

      <style>{`
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-6px); }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}

function SendIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M22 2L11 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

const C = {
  bgDark: '#110800',
  rojo: '#C1121F',
  amarillo: '#F4A300',
  verde: '#2D6A4F',
  verdeLight: '#52B788',
  naranja: '#E85D04',
  crema: '#FFF3DC',
}

const styles = {
  root: {
    display: 'flex',
    flexDirection: 'column' as const,
    height: '100dvh',
    maxWidth: 420,
    margin: '0 auto',
    background: C.bgDark,
    fontFamily: "'Segoe UI', system-ui, sans-serif",
    position: 'relative' as const,
    overflow: 'hidden',
  },
  header: {
    background: C.verde,
    boxShadow: '0 2px 8px rgba(0,0,0,0.4)',
    zIndex: 10,
    flexShrink: 0,
  },
  headerInner: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    padding: '12px 16px 10px',
  },
  headerName: {
    color: C.crema,
    fontWeight: 700,
    fontSize: 16,
  },
  headerSub: {
    color: C.verdeLight,
    fontSize: 12,
    marginTop: 1,
  },
  progressBar: {
    height: 3,
    background: `${C.verdeLight}44`,
  },
  progressFill: {
    height: '100%',
    background: C.amarillo,
    borderRadius: 2,
    transition: 'width 0.4s ease',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: '50%',
    background: C.amarillo,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    boxShadow: `0 0 0 2px ${C.naranja}`,
  },
  chatArea: {
    flex: 1,
    overflowY: 'auto' as const,
    position: 'relative' as const,
  },
  patternOverlay: {
    position: 'absolute' as const,
    inset: 0,
    opacity: 0.04,
    backgroundImage: `repeating-linear-gradient(45deg, ${C.amarillo} 0px, ${C.amarillo} 1px, transparent 1px, transparent 20px)`,
    pointerEvents: 'none' as const,
  },
  messages: {
    padding: '16px 12px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: 6,
    position: 'relative' as const,
    zIndex: 1,
  },
  bubble: {
    bot: {
      background: '#1e2a1a',
      border: `1px solid ${C.verde}55`,
      color: C.crema,
      borderRadius: '4px 18px 18px 18px',
      padding: '10px 14px',
      fontSize: 14.5,
      lineHeight: 1.5,
      maxWidth: 280,
      animation: 'fadeIn 0.25s ease',
      boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
    } as React.CSSProperties,
    user: {
      background: C.verde,
      color: C.crema,
      borderRadius: '18px 4px 18px 18px',
      padding: '10px 14px',
      fontSize: 14.5,
      lineHeight: 1.5,
      maxWidth: 280,
      animation: 'fadeIn 0.2s ease',
      boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
    } as React.CSSProperties,
  },
  timestamp: {
    fontSize: 11,
    color: '#ffffff44',
    marginTop: 3,
    paddingLeft: 4,
  },
  typing: {
    display: 'flex',
    gap: 4,
    alignItems: 'center',
    padding: '4px 2px',
  },
  dot: {
    display: 'inline-block',
    width: 7,
    height: 7,
    borderRadius: '50%',
    background: C.verdeLight,
    animation: 'bounce 1.2s infinite',
  } as React.CSSProperties,
  inputArea: {
    background: '#1a1000',
    borderTop: `1px solid ${C.verde}44`,
    padding: '10px 12px',
    flexShrink: 0,
  },
  inputRow: {
    display: 'flex',
    gap: 8,
    alignItems: 'center',
  },
  input: {
    flex: 1,
    background: '#2a1a00',
    border: `1px solid ${C.verde}66`,
    borderRadius: 24,
    padding: '10px 16px',
    color: C.crema,
    fontSize: 14,
    outline: 'none',
    caretColor: C.amarillo,
  } as React.CSSProperties,
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: '50%',
    background: C.verde,
    border: 'none',
    color: C.crema,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    flexShrink: 0,
  } as React.CSSProperties,
  optionsGrid: {
    display: 'flex',
    flexWrap: 'wrap' as const,
    gap: 8,
  },
  optionBtn: {
    background: 'transparent',
    border: `1.5px solid ${C.amarillo}`,
    color: C.amarillo,
    borderRadius: 20,
    padding: '8px 16px',
    fontSize: 13.5,
    cursor: 'pointer',
    fontWeight: 600,
  } as React.CSSProperties,
  doneBar: {
    background: C.verde,
    padding: '14px 20px',
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    justifyContent: 'center',
    flexShrink: 0,
  },
  // Confirm screen
  confirmRoot: {
    background: '#1a1000',
    border: `1px solid ${C.verde}55`,
    borderRadius: 16,
    padding: 16,
    display: 'flex',
    flexDirection: 'column' as const,
    gap: 12,
  },
  confirmHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    paddingBottom: 8,
    borderBottom: `1px solid ${C.verde}33`,
  },
  confirmTitle: {
    color: C.crema,
    fontWeight: 700,
    fontSize: 16,
  },
  confirmSubtitle: {
    color: `${C.crema}88`,
    fontSize: 12,
    marginTop: 2,
  },
  confirmCards: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: 8,
  },
  confirmCard: {
    background: '#241500',
    border: `1px solid ${C.verde}33`,
    borderRadius: 10,
    padding: '10px 12px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  confirmCardLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    minWidth: 0,
  },
  confirmLabel: {
    color: `${C.crema}77`,
    fontSize: 11,
    marginBottom: 2,
    textTransform: 'uppercase' as const,
    letterSpacing: 0.5,
  },
  confirmValue: {
    color: C.crema,
    fontSize: 14,
    fontWeight: 500,
    whiteSpace: 'nowrap' as const,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    maxWidth: 190,
  },
  editBtn: {
    background: 'transparent',
    border: `1px solid ${C.amarillo}66`,
    color: C.amarillo,
    borderRadius: 8,
    padding: '4px 10px',
    fontSize: 12,
    cursor: 'pointer',
    flexShrink: 0,
    fontWeight: 500,
  } as React.CSSProperties,
  submitBtn: {
    background: C.naranja,
    border: 'none',
    color: C.crema,
    borderRadius: 12,
    padding: '14px',
    fontSize: 15,
    fontWeight: 700,
    cursor: 'pointer',
    width: '100%',
    letterSpacing: 0.3,
  } as React.CSSProperties,
  confirmNote: {
    color: `${C.crema}55`,
    fontSize: 11,
    textAlign: 'center' as const,
    margin: 0,
    lineHeight: 1.4,
  },
  errorBox: {
    background: `${C.rojo}22`,
    border: `1px solid ${C.rojo}66`,
    color: '#ff6b6b',
    borderRadius: 8,
    padding: '10px 12px',
    fontSize: 13,
  },
}
import { useEffect, useRef } from 'react'
import { Zap } from 'lucide-react'

interface PointsCounterProps {
  points: number
  threshold?: number
  animated?: boolean
  size?: 'sm' | 'md' | 'lg'
  showProgress?: boolean
  className?: string
}

export default function PointsCounter({
  points,
  threshold = 200,
  animated = true,
  size = 'md',
  showProgress = false,
  className = '',
}: PointsCounterProps) {
  const prevRef = useRef(0)
  const displayRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    if (!animated || !displayRef.current) {
      prevRef.current = points
      return
    }
    const start = prevRef.current
    const end = points
    const duration = 800
    const startTime = performance.now()

    const step = (now: number) => {
      const elapsed = now - startTime
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      const current = Math.round(start + (end - start) * eased)
      if (displayRef.current) displayRef.current.textContent = current.toLocaleString('es-MX')
      if (progress < 1) requestAnimationFrame(step)
      else prevRef.current = end
    }
    requestAnimationFrame(step)
  }, [points, animated])

  const sizeMap = {
    sm: { wrapper: 'px-3 py-1.5 gap-1.5', icon: 14, text: 'text-sm font-bold', label: 'text-xs' },
    md: { wrapper: 'px-4 py-2 gap-2',     icon: 16, text: 'text-xl font-black', label: 'text-xs' },
    lg: { wrapper: 'px-5 py-3 gap-3',     icon: 22, text: 'text-3xl font-black', label: 'text-sm' },
  }

  const cfg = sizeMap[size]
  const pct = Math.min((points / threshold) * 100, 100)
  const ready = points >= threshold

  return (
    <div className={`inline-flex flex-col gap-1 ${className}`}>
      <div
        className={`inline-flex items-center ${cfg.wrapper} rounded-2xl border transition-all duration-300 ${
          ready
            ? 'bg-[#F4A300]/20 border-[#F4A300] shadow-[0_0_12px_rgba(244,163,0,0.3)]'
            : 'bg-[#1a0f00] border-[#3d2200]'
        }`}
      >
        <Zap
          size={cfg.icon}
          className={`shrink-0 ${ready ? 'text-[#F4A300]' : 'text-[#F4A300]/60'}`}
          fill={ready ? '#F4A300' : 'transparent'}
        />
        <span ref={displayRef} className={`${cfg.text} text-[#FFF3DC] tabular-nums`}>
          {points.toLocaleString('es-MX')}
        </span>
        <span className={`${cfg.label} text-[#FFF3DC]/50 font-medium`}>pts</span>
      </div>

      {showProgress && (
        <div className="flex flex-col gap-1">
          <div className="w-full h-1.5 bg-[#1a0f00] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${pct}%`,
                background: ready
                  ? 'linear-gradient(90deg, #F4A300, #ffcc44)'
                  : 'linear-gradient(90deg, #C1121F, #F4A300)',
              }}
            />
          </div>
          <p className="text-[10px] text-[#FFF3DC]/40 text-right">
            {ready
              ? '¡Listo para abrir sobre!'
              : `${threshold - points} pts para el siguiente sobre`}
          </p>
        </div>
      )}
    </div>
  )
}
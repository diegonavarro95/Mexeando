import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { api } from '../services/api';

interface Props {
  businessId: string;
}

export const BusinessQRCode = ({ businessId }: Props) => {
  const [qrImageUrl, setQrImageUrl] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchRealQR = async () => {
      try {
        setLoading(true);


        const response = await api.get(`/api/v1/businesses/${businessId}/qr-token`);
        
        const qrContent = response.data.data.qr_content;

        const imageUrl = await QRCode.toDataURL(qrContent, {
          width: 800,
          margin: 2,
          color: { dark: '#000000', light: '#ffffff' }
        });

        setQrImageUrl(imageUrl);
      } catch (error) {
        console.error("Error al obtener el QR del backend:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchRealQR();
  }, [businessId]);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = qrImageUrl;
    link.download = `CheckIn_Garnacha_${businessId}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) return (
    <div className="p-8 text-center">
      <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#C1121F] mb-2"></div>
      <p className="text-gray-500 font-medium">Conectando con el servidor...</p>
    </div>
  );

  return (
    <div className="flex flex-col items-center p-6 bg-[#FFF3DC] rounded-2xl shadow-xl max-w-sm mx-auto border border-gray-200">
      <h2 className="text-2xl font-extrabold text-[#110800] mb-6">QR de Check-in</h2>
      
      {qrImageUrl ? (
        <>
          <div className="bg-white p-4 rounded-xl mb-6 shadow-sm border border-gray-100">
            <img src={qrImageUrl} alt="QR Code" className="w-56 h-56" />
          </div>
          <button 
            onClick={handleDownload}
            className="w-full bg-[#C1121F] hover:bg-red-800 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg active:scale-95"
          >
            Descargar PNG (Alta Res)
          </button>
          <p className="mt-4 text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Listo para impresión A4</p>
        </>
      ) : (
        <p className="text-red-500 font-bold">Error al generar QR</p>
      )}
    </div>
  );
};